//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let stringLabel = UILabel(frame: CGRect(x: 20, y: 40, width: 350, height: 40))
    
    let stringTextField = UITextField(frame: CGRect(x: 20, y: 80, width: 350, height: 40))
    
    let findLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 80, height: 40))
    let findTextField = UITextField(frame: CGRect(x: 100, y: 150, width: 100, height: 40))
    
    let replaceLabel = UILabel(frame: CGRect(x: 220, y: 150, width: 100, height: 40))
    let replaceTextField = UITextField(frame: CGRect(x: 320, y: 150, width: 100, height: 40))
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 300, width: 300, height: 40))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        stringLabel.text = "Enter a phrase below"
        view.addSubview(stringLabel)
        
        stringTextField.backgroundColor = UIColor.lightGray
        view.addSubview(stringTextField)
        
        findLabel.text = "Find:"
        view.addSubview(findLabel)
        findTextField.backgroundColor = .lightGray
        view.addSubview(findTextField)
        
        replaceLabel.text = "Replace:"
        view.addSubview(replaceLabel)
        replaceTextField.backgroundColor = .lightGray
        view.addSubview(replaceTextField)
        
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Replace Letter", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        button.resignFirstResponder()
        let phrase = stringTextField.text!
        let letterToFind = findTextField.text!
        let letterToReplace = replaceTextField.text!
        totalLabel.text = "\( findAndReplace(phrase:phrase,letterToFind:letterToFind, letterToReplace: letterToReplace) )"
    }
    
    
//#-end-hidden-code
//: Enter the code inside the function to remove all occurances of the letter to find and replace them with the new letter. You cannot use replacingOccurrences and you must use a loop.
//:
//:
    func findAndReplace(phrase: String, letterToFind: String, letterToReplace:String) -> String
    {
        <#Code#>
    }
    
//#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


