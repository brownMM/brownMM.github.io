/*:
 # To Enter Your Class Lists
 - Use the PickerView at the top to select the desired period
 - Tap inside the numbered ClassListView to bring up the keyboard
 - Enter each name
 - Hit return after each name
 - Dismiss the keyboard when done
*/
//: ![Keyboard Picture](Keyboard.png)
/*:
 # To Enter Your Group Names
 - Tap on the TextField that says **Enter GroupName Here...**
 - Enter the name you want for a group and hit return.
    - Do not use spaces
    - Use only Letters and Numbers (capital or lowercase)
    - UseCamelCaseToSimulateSpaces (Camel case capitalizes the first letter of each word)
 # To Use Group-i-fier
 - Tap on > at top of page to go to Group Maker
 */
//: ![Navigate to New Page](Arrow.png)
/*:
 # To Delete a Group
 - Select the group in the picker
 - Hit the **Delete Group** button
 # To Delete a Student
 - Simply remove the students name from the class Lists
 - Dismiss the keyboard
 */

//:
//:
//: Copyright (c) 2017
//: Bob Brown and Tom Davidsmeier. All Rights Reserved.
//: All the good stuff is by Thomas Davidsmeier.
//: Bob Brown made all the parts that don't work.
