//
//  LiveView.swift
//
//  Copyright (c) 2017 Bob Brown and Tom Davidsmeier. All Rights Reserved.
//  All the good stuff is by Thomas Davidsmeier.
//  Bob Brown made all the parts that don't work.


import PlaygroundSupport
import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate, UITextViewDelegate {
    
    let contentView = UIView(frame: CGRect(x: 0, y: 0, width: 430, height: 1700))
    let scrollContentView = UIScrollView(frame: CGRect(x: 0, y: 0, width: 430, height: 1000))
    
    let picker = UIPickerView(frame: CGRect(x: 15, y: 15, width: 403, height: 105))
    let classListLabel = UILabel(frame: CGRect(x: 5, y: 120, width: 420, height: 25))
    let scrollView = UIScrollView(frame: CGRect(x: 15, y: 150, width: 403, height: 280))
    let numberTextView = UITextView(frame: CGRect(x: 0, y: 0, width: 50, height: 1750))
    let textView = UITextView(frame: CGRect(x: 51, y: 0, width: 352, height: 1750))
    
    let groupsLabel = UILabel(frame: CGRect(x: 5, y: 430, width: 420, height: 25))
    let textField = UITextField(frame: CGRect(x: 15, y: 460, width: 285, height: 45))
    let deleteButton = UIButton(frame: CGRect(x: 305, y: 460, width: 115, height: 45))
    let picker2 = UIPickerView(frame: CGRect(x: 15, y: 510, width: 403, height: 105))
    
    var classes = ["Period 1", "Period 2","Period 3", "Period 4","Period 5", "Period 6","Period 7", "Period 8"]
    var classNames = ["period1", "period2","period3", "period4","period5", "period6","period7", "period8"]
    
    var currentGroupNames = [String]()
    var currentStudentNames = [String]()
    var currentClass = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.delegate = self
        picker.backgroundColor = .orange
        contentView.addSubview(picker)
        
        classListLabel.text = "Class List"
        classListLabel.font = UIFont(name: "Times", size: 20.0)
        classListLabel.textColor = .white
        classListLabel.textAlignment = .center
        contentView.addSubview(classListLabel)
        
        numberTextView.isEditable = false
        numberTextView.font = UIFont(name: "Times", size: 30)
        numberTextView.text = "  1.\n  2.\n  3.\n  4.\n  5.\n  6.\n  7.\n  8.\n  9.\n10.\n11.\n12.\n13.\n14.\n15.\n16.\n17.\n18.\n19.\n20.\n21.\n22.\n23.\n24.\n25.\n26.\n27.\n28.\n29.\n30.\n31.\n32.\n33.\n34.\n35.\n36.\n37.\n38.\n39.\n40.\n41.\n42.\n43.\n44.\n45.\n46.\n47.\n48.\n49.\n50."
        scrollView.addSubview(numberTextView)
        
        textView.delegate = self
        textView.isEditable = true
        textView.font = UIFont(name: "Times", size: 30)
        
        var currentNames = ""
        currentClass = "period1"
        
        if let keyValue = PlaygroundKeyValueStore.current[currentClass],
            case .array(let names) = keyValue {
            for name in names {
                if case .string(let babyKeyValue) = name {
                    if babyKeyValue != "\n" {
                    currentNames += "\(babyKeyValue)\n"
                    }
                }
            }
        }
        currentStudentNames = currentNames.components(separatedBy: "\n")
        textView.text = currentNames
        
        scrollView.contentSize = CGSize(width: 403, height: 1750)
        scrollView.addSubview(textView)
        contentView.addSubview(scrollView)
        
        groupsLabel.text = "Group List"
        groupsLabel.font = UIFont(name: "Times", size: 20.0)
        groupsLabel.textColor = .white
        groupsLabel.textAlignment = .center
        contentView.addSubview(groupsLabel)
        
        picker2.delegate = self
        picker2.backgroundColor = .orange
        
        textField.delegate = self
        textField.backgroundColor = .white
        textField.placeholder = "Enter GroupName Here..."
        textField.font = UIFont(name: "Times", size: 20)
        contentView.addSubview(textField)
        
        deleteButton.backgroundColor = .black
        deleteButton.setTitle("Delete Group", for: .normal)
        deleteButton.addTarget(self, action: #selector(deleteGroup), for: .touchUpInside)
        deleteButton.addTarget(self, action: #selector(changeColor), for: .touchDown)
        contentView.addSubview(deleteButton)
        
        contentView.addSubview(picker2)
        
        scrollContentView.contentSize = CGSize(width: 430, height: 1700)
        scrollContentView.isScrollEnabled = false
        scrollContentView.addSubview(contentView)
        view.addSubview(scrollContentView)
        
        loadGroups()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name:NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name:NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let label = UILabel()
        label.font = UIFont(name: "Times", size: 35.0)
        label.textAlignment = .center
        label.textColor = .white
        if pickerView == picker
        {
            label.text = classes[row]
        }
        else
        {
            label.text = currentGroupNames[row]
        }
        
        return label
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40.0
    }

    func loadGroups() {
        currentClass = classNames[picker.selectedRow(inComponent: 0)]
        if let keyValue = PlaygroundKeyValueStore.current[currentClass + "Groups"], case .dictionary(let names) = keyValue {
            
            for (groupName, _) in names {
                currentGroupNames.append(groupName)
            }
        }
        picker2.reloadAllComponents()
    }
    
    func localListOfGroups(from aClass: String) -> [String] {
        var localList = [String]()
    
        if let keyValue = PlaygroundKeyValueStore.current[aClass + "Groups"], case .dictionary(let names) = keyValue {
            
            for (groupName, _) in names {
                localList.append(groupName)
            }
        }
    
        return localList
    }
    
    func localCopyOfGroups(from aClass: String) -> [String:String] {
        var localCopy = [String:String]()
        
        if let keyValue = PlaygroundKeyValueStore.current[aClass + "Groups"], case .dictionary(let names) = keyValue {
            
            for (groupName, line) in names {
                if case .string(let newLine) = line
                {
                    localCopy[groupName] = newLine
                }
            }
        }
        
        else {
            localCopy["Oops"] = "This Sucks!"
        }
        
        return localCopy
    }

    
    func saveGroups() {
        
        var dictionaryOfGroupsToBeSaved = [String:PlaygroundValue]()
        currentClass = classNames[picker.selectedRow(inComponent: 0)]
        var listOfStoredGroupNames = localListOfGroups(from: currentClass)
        var copyOfStoredGroupSetups = localCopyOfGroups(from: currentClass)
        
        for currentGroup in currentGroupNames {
            var groupIsOld = listOfStoredGroupNames.contains{$0 == currentGroup}

            if groupIsOld{
                var newSetup = String()
                var oldX = 0
                var oldY = 0
                var newX = 0
                var newY = 0
                
                let oldSetup = copyOfStoredGroupSetups[currentGroup]!.components(separatedBy: "/")
                
                for newName in currentStudentNames {
                    var nameWasWritten = false
                    for studentSetup in oldSetup {
                        if studentSetup.hasPrefix(newName) {
                            newSetup += "\(studentSetup)/"
                            nameWasWritten = true
                            break
                        }
                    }
                    if nameWasWritten == false {
                        for studentSetup in oldSetup {
                            if studentSetup.hasSuffix("\(newX);\(newY)") {
                                if newY < 9 {
                                    newY += 1
                                } else {
                                    newX += 1
                                    newY = 0
                                }
                            }
                        }
                        newSetup += "\(newName);\(newX);\(newY)/"
                        if newY < 9 {
                            newY += 1
                        } else {
                            newX += 1
                            newY = 0
                        }
                    }
                }
                
                dictionaryOfGroupsToBeSaved[currentGroup] = PlaygroundValue.string(newSetup)
            }
            else{
                dictionaryOfGroupsToBeSaved[currentGroup] = PlaygroundValue.string("empty")
            }
        }
        
        if currentGroupNames.count != 0 {
            PlaygroundKeyValueStore.current[currentClass + "Groups"] = PlaygroundValue.dictionary(dictionaryOfGroupsToBeSaved)
        }

    }
    
    func deleteGroup(_ button: UIButton) {
        button.backgroundColor = .black
        let value = picker2.selectedRow(inComponent: 0)
        if currentGroupNames.count != 0
        {
            currentGroupNames.remove(at: value)
        }
        picker2.reloadAllComponents()
        saveGroups()
        
    }
    
    func keyboardWillShow(_ notification: Notification) {
        if textField.isEditing {
            self.contentView.frame.origin.y -= 434
        }
    }
    
    func keyboardWillHide(_ notification: Notification) {
        if textField.isEditing {
            self.contentView.frame.origin.y += 434
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        let groupName = textField.text!
        
        if hasBadCharacter(string: groupName)
        {
            textField.resignFirstResponder()
            let message = "You have entered a name for your groups that contains invalid characters. Names must begin with a letter and contain only letters and numbers. Use Camel Case for clarity"
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) in
                self.textField.text = ""
            })
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        }
        else
        {
            currentGroupNames.append(groupName)
            picker2.reloadAllComponents()
            saveGroups()
            textField.text = ""
        }
        return true
    }
    
    func hasBadCharacter(string: String) -> Bool
    {
        let bad = "!@#$%^&*()-+=~`:;\"'{[}]|\\<,>.?/ "
        
        for letter in string.characters
        {
            for character in bad.characters
            {
                if letter == character
                {
                    return true
                }
            }
        }
        return false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        textView.resignFirstResponder()
        saveToFile()
    }
    
    func changeColor(_ button: UIButton)
    {
        button.backgroundColor = .white
    }
    
    func saveToFile()
    {
        textView.resignFirstResponder()
        let names = textView.text!
        currentStudentNames = names.components(separatedBy: "\n")
        var studentNamesToStore = [PlaygroundValue]()
        for name in currentStudentNames
        {
            if name != "" {
                studentNamesToStore.append(PlaygroundValue.string(name))
            }
        }
        
        currentClass = classNames[picker.selectedRow(inComponent: 0)]
        PlaygroundKeyValueStore.current[currentClass] = PlaygroundValue.array(studentNamesToStore)
        
        saveGroups()
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == picker
        {
            currentGroupNames = [String]()
            picker2.reloadAllComponents()
            textView.text = ""
            
            let currentClass = classNames[row]
            var currentNames = ""
            if let keyValue = PlaygroundKeyValueStore.current[currentClass],
                case .array(let names) = keyValue {
                for name in names {
                    if case .string(let babyKeyValue) = name {
                        currentNames += "\(babyKeyValue)\n"
                    }
                }
            }
            textView.text = currentNames
            
            loadGroups()
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == picker
        {
            return classes.count
        }
        else
        {
            return currentGroupNames.count
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == picker
        {
            return classes[row]
        }
        else
        {
            return currentGroupNames[row]
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        self.contentView.frame.origin.y += 124
        saveToFile()
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        self.contentView.frame.origin.y -= 124
    }
    
    func debug(_ message: String)
    {
        let alert = UIAlertController(title: "Testing String", message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) in
            
        })
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    
    func debugArray(_ message: [String])
    {
        var myString = ""
        for word in message
        {
            myString += "\(word)\n"
        }
        
        let alert = UIAlertController(title: "Testing Array", message: myString, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) in
            
        })
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
}

let controller = ViewController()

PlaygroundPage.current.liveView = controller
