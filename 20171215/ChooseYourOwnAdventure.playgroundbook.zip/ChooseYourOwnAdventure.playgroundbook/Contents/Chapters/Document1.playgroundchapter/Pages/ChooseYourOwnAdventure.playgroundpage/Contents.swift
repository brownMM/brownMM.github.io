//#-hidden-code
import UIKit
import PlaygroundSupport

import UIKit
import PlaygroundSupport

class ViewController: UIViewController {
    
    let stackViewContainer = UIStackView()
    
    var textView1 = UITextView()
    var textView2 = UITextView()
    var textView3 = UITextView()
    var summary = UITextView()
    
    var button1 = UIButton()
    var button2 = UIButton()
    var button3 = UIButton()
    var button4 = UIButton()
    var buttonArray:[UIButton] = []
    
    var startOfStory:String!
    var choice1:String!
    var choice1Text:String!
    var choice2:String!
    var choice2Text:String!
    var choice3:String!
    var choice3Text:String!
    var choice4:String!
    var choice4Text:String!
    var choice5:String!
    var choice5Text:String!
    var choice6:String!
    var choice6Text:String!
    
    override func viewDidLoad() {
        
        buttonArray = [button1,button2,button3,button4]
        clearButtons()
        
        stackViewContainer.axis = .vertical
        stackViewContainer.spacing = 10
        stackViewContainer.distribution = .fillEqually
        
        textView1.font = UIFont(name: "Times", size: 20.0)
        stackViewContainer.addArrangedSubview(textView1)
        
        let stackViewRow2 = UIStackView()
        stackViewRow2.axis = .horizontal
        stackViewRow2.spacing = 10
        stackViewRow2.distribution = .fillEqually
        
        button1.backgroundColor = .white
        button1.setTitleColor(.blue, for: .normal)
        button1.addTarget(self, action: #selector(firstChoiceClicked), for: .touchUpInside)
        
        button2.backgroundColor = .white
        button2.setTitleColor(.blue, for: .normal)
        button2.addTarget(self, action: #selector(firstChoiceClicked), for: .touchUpInside)
        stackViewRow2.addArrangedSubview(button1)
        stackViewRow2.addArrangedSubview(button2)
        
        stackViewContainer.addArrangedSubview(stackViewRow2)
        
        textView2.font = UIFont(name: "Times", size: 20.0)
        stackViewContainer.addArrangedSubview(textView2)
        
        let stackViewRow4 = UIStackView()
        stackViewRow4.axis = .horizontal
        stackViewRow4.spacing = 10
        stackViewRow4.distribution = .fillEqually
        
        button3.backgroundColor = .white
        button3.setTitleColor(.blue, for: .normal)
        button3.addTarget(self, action: #selector(secondChoiceClicked), for: .touchUpInside)
        
        button4.backgroundColor = .white
        button4.setTitleColor(.blue, for: .normal)
        button4.addTarget(self, action: #selector(secondChoiceClicked), for: .touchUpInside)
        
        stackViewRow4.addArrangedSubview(button3)
        stackViewRow4.addArrangedSubview(button4)
        
        stackViewContainer.addArrangedSubview(stackViewRow4)
        
        textView3.font = UIFont(name: "Times", size: 20.0)
        stackViewContainer.addArrangedSubview(textView3)
        
        summary.font = UIFont(name: "Times", size: 25.0)
        stackViewContainer.addArrangedSubview(summary)
        
        self.view = stackViewContainer
        
        start()
        setUpPaths()
    }
    
    func clearButtons() {
        for button in buttonArray {
            button.tag = 0
        }
    }
    
    func start() {
        //#-end-hidden-code
//: Choose Your Own Adventure
//: First complete the enclosed worksheet, then fill in the choices.
startOfStory = /*#-editable-code placeholder text*/"<#Begin Your Story Here#>"/*#-end-editable-code*/
        //#-hidden-code
        textView1.text = startOfStory
    }
    
    func setUpPaths() {
        //#-end-hidden-code
//: Here you are going to set up your path decisions
//: First Path-
choice1 = /*#-editable-code placeholder text*/"<#Choice #1#>"/*#-end-editable-code*/
choice3 = /*#-editable-code placeholder text*/"<#Choice #3#>"/*#-end-editable-code*/
choice4 = /*#-editable-code placeholder text*/"<#Choice #4#>"/*#-end-editable-code*/
//: Second Path-
choice2 = /*#-editable-code placeholder text*/"<#Choice #2#>"/*#-end-editable-code*/
choice5 = /*#-editable-code placeholder text*/"<#Choice #5#>"/*#-end-editable-code*/
choice6 = /*#-editable-code placeholder text*/"<#Choice #6#>"/*#-end-editable-code*/
        //#-hidden-code
        
        button1.setTitle(choice1, for: .normal)
        button2.setTitle(choice2, for: .normal)
    }
    
    
    @objc func firstChoiceClicked(button: UIButton) {
        
        if let path = button.titleLabel?.text {
            //#-end-hidden-code
//: Here is where you code the choices to make
//:
if path == choice1 {
    display(show: /*#-editable-code*/"<#Choice #1 Text#>"/*#-end-editable-code*/)
            //#-hidden-code
                button1.tag = 1
                button2.tag = 0
                button3.setTitle(choice3, for: .normal)
                button4.setTitle(choice4, for: .normal)
                //#-end-hidden-code
} else if path == choice2 {
    display(show: /*#-editable-code placeholder text*/"<#Choice #2 Text#>"/*#-end-editable-code*/)
                //#-hidden-code
                button1.tag = 1
                button2.tag = 0
                button3.setTitle(choice5, for: .normal)
                button4.setTitle(choice6, for: .normal)
                //#-end-hidden-code
}
            //#-hidden-code
        }
        
    }
    
    func display(show: String) {
        
        textView2.text = show
    }
    
    
    
    @objc func secondChoiceClicked(button: UIButton) {
        
        if let path = button.titleLabel?.text {
            //#-end-hidden-code
//: Here is where you code the choices to make
if path == choice3 {
    nowDisplay(show: /*#-editable-code placeholder text*/"<#Choice #3 Text#>"/*#-end-editable-code*/)
} else if path == choice4 {
    nowDisplay(show: /*#-editable-code placeholder text*/"<#Choice #4 Text#>"/*#-end-editable-code*/)
}
            
//: Here is where you code the choices to make
if path == choice5 {
    nowDisplay(show: /*#-editable-code placeholder text*/"<#Choice #5 Text#>"/*#-end-editable-code*/)
} else if path == choice6 {
    nowDisplay(show: /*#-editable-code placeholder text*/"<#Choice #6 Text#>"/*#-end-editable-code*/)
}
            //#-hidden-code
            summary.text = textView1.text + " " + textView2.text + " " + textView3.text
        }
        
    }
    
    func nowDisplay(show: String) {
        textView3.text = show
    }
    
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

