//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let integerLabel = UILabel(frame: CGRect(x: 20, y: 40, width: 350, height: 40))
    
    let integerTextField = UITextField(frame: CGRect(x: 20, y: 80, width: 100, height: 40))
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 300, height: 40))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 250, height: 25))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        integerLabel.text = "Enter an Integer Below"
        view.addSubview(integerLabel)
        
        integerTextField.backgroundColor = UIColor.lightGray
        view.addSubview(integerTextField)
        
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Reverse the Integer", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    func whenPressed(_ button: UIButton)
    {
        let integer = Int(integerTextField.text!)!
        totalLabel.text = "\(integer) backwards is \( reverse(number: integer))"
    }
    
    
    //#-end-hidden-code
//: Enter the code inside the function to take the integer argument, number, and reverse every digit. You must use a loop and the data type returned must be an integer.
//:
    func reverse(number: Int) -> Int
    {
        <#code#>
    }
    //#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
