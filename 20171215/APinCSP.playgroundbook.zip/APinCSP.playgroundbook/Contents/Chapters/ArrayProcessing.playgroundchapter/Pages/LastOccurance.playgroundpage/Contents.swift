//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let ElementLabel0 = UILabel(frame: CGRect(x: 20, y: 40, width: 40, height: 40))
    let ElementLabel1 = UILabel(frame: CGRect(x: 100, y: 40, width: 40, height: 40))
    let ElementLabel2 = UILabel(frame: CGRect(x: 180, y: 40, width: 40, height: 40))
    let ElementLabel3 = UILabel(frame: CGRect(x: 260, y: 40, width: 40, height: 40))
    let ElementLabel4 = UILabel(frame: CGRect(x: 340, y: 40, width: 40, height: 40))
    
    let ElementTextField0 = UITextField(frame: CGRect(x: 20, y: 80, width: 40, height: 40))
    let ElementTextField1 = UITextField(frame: CGRect(x: 100, y: 80, width: 40, height: 40))
    let ElementTextField2 = UITextField(frame: CGRect(x: 180, y: 80, width: 40, height: 40))
    let ElementTextField3 = UITextField(frame: CGRect(x: 260, y: 80, width: 40, height: 40))
    let ElementTextField4 = UITextField(frame: CGRect(x: 340, y: 80, width: 40, height: 40))
    
    let locationLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 400, height: 100))
    let keyLabel = UILabel(frame: CGRect(x: 20, y: 10, width: 50, height: 40))
    let keyTextField = UITextField(frame: CGRect(x: 75, y: 10, width: 50, height: 40))
    let locationButton = UIButton(frame: CGRect(x: 130, y: 10 , width: 225, height: 25))
    
    var array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        keyLabel.text = "Key:"
        view.addSubview(keyLabel)
        
        ElementLabel0.text = "0"
        ElementLabel0.textAlignment = .center
        ElementLabel1.text = "1"
        ElementLabel1.textAlignment = .center
        ElementLabel2.text = "2"
        ElementLabel2.textAlignment = .center
        ElementLabel3.text = "3"
        ElementLabel3.textAlignment = .center
        ElementLabel4.text = "4"
        ElementLabel4.textAlignment = .center
        
        view.addSubview(ElementLabel0)
        view.addSubview(ElementLabel1)
        view.addSubview(ElementLabel2)
        view.addSubview(ElementLabel3)
        view.addSubview(ElementLabel4)
        
        ElementTextField0.backgroundColor = UIColor.lightGray
        ElementTextField0.textAlignment = .center
        ElementTextField0.keyboardType = .numberPad
        ElementTextField1.backgroundColor = UIColor.lightGray
        ElementTextField1.textAlignment = .center
        ElementTextField1.keyboardType = .numberPad
        ElementTextField2.backgroundColor = UIColor.lightGray
        ElementTextField2.textAlignment = .center
        ElementTextField2.keyboardType = .numberPad
        ElementTextField3.backgroundColor = UIColor.lightGray
        ElementTextField3.textAlignment = .center
        ElementTextField3.keyboardType = .numberPad
        ElementTextField4.backgroundColor = UIColor.lightGray
        ElementTextField4.textAlignment = .center
        ElementTextField4.keyboardType = .numberPad
        keyTextField.backgroundColor = UIColor.lightGray
        keyTextField.textAlignment = .center
        keyTextField.keyboardType = .numberPad
        
        view.addSubview(ElementTextField0)
        view.addSubview(ElementTextField1)
        view.addSubview(ElementTextField2)
        view.addSubview(ElementTextField3)
        view.addSubview(ElementTextField4)
        view.addSubview(keyTextField)
        
        locationLabel.numberOfLines = 2
        view.addSubview(locationLabel)
        
        locationButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        locationButton.setTitle("Find the element number", for: .normal)
        locationButton.setTitleColor(UIColor.white, for: .normal)
        locationButton.backgroundColor = .blue
        view.addSubview(locationButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        array = [Int(ElementTextField0.text!)!,Int(ElementTextField1.text!)!,Int(ElementTextField2.text!)!,Int(ElementTextField3.text!)!,Int(ElementTextField4.text!)!]
        let key = Int(keyTextField.text!)!
        let location = lastOccurance(array: array, key: key)
        locationLabel.text = "With your code, the key was in location \(location)"
    }
    
    
//#-end-hidden-code
//: Enter the code inside the function to find the last location in the array of the key provided. If the key is not in the array, return the value -1. You must use a loop and cannot use indexof. Do not assume you know the length of the array.
//:
    func lastOccurance(array: [Int], key: Int) -> Int
    {
        <#code#>
    }
    //#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


