//
//  Grid.swift
//
//  Copyright (c) 2017 Bob Brown and Tom Davidsmeier. All Rights Reserved.
//  All the good stuff is by Thomas Davidsmeier.
//  Bob Brown made all the parts that don't work.

import UIKit


public struct Grid {
    
    public var width = Int()
    
    public var height = Int()
    
    public var offset = CGPoint()
    
    public var maxX = 10
    
    public var maxY = 10
    
    public init(width: Int, height: Int, offset: CGPoint){
        self.width = width
        self.height = height
        self.offset = offset
    }
    
    public var CGFwidth: CGFloat {
        return CGFloat(width)
    }
    
    public var CGFheight: CGFloat {
        return CGFloat(height)
    }
    
    public var DBLwidth: Double {
        return Double(width)
    }
    
    public var DBLheight: Double {
        return Double(height)
    }
    
    public func snapThisPointToMe(_ point: CGPoint) -> CGPoint{
        return CGPoint(x: screenX(gridX(point)), y: screenY(gridY(point)))
    }
    
    public func snapThisToMyGridPoint(gridX: Int, gridY: Int) -> CGPoint{
        return CGPoint(x: screenX(gridX), y: screenY(gridY))
    }
    
    public func screenX(_ gridX: Int) -> CGFloat {
        return CGFloat(gridX*width) + offset.x
    }
    
    public func screenY(_ gridY: Int) -> CGFloat {
        return CGFloat(gridY*height) + offset.y
    }
    
    public func gridX(_ point: CGPoint) -> Int {
        
        var localX = point.x - offset.x
        var gridXvar = Int(localX/CGFwidth)
        
        localX.formTruncatingRemainder(dividingBy: CGFwidth)
        
        if Int(localX) > width/2 {
            gridXvar += 1
        }
        if gridXvar < 0 {gridXvar = 0}
        
        if gridXvar > maxX {gridXvar = maxX}
        
        return gridXvar
    }
    
    public func gridY(_ point: CGPoint) -> Int {
        var localY = point.y - offset.y
        var gridYvar = Int(localY/CGFheight)
        
        localY.formTruncatingRemainder(dividingBy: CGFheight)
        if Int(localY) > height/2 {
            gridYvar += 1
        }
        if gridYvar < 0 {gridYvar = 0}
        
        if gridYvar > maxY {gridYvar = maxY}
        
        return gridYvar
    }
}
