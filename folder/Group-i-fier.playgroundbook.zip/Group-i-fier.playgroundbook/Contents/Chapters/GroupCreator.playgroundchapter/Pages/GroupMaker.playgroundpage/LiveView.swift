//
//  LiveView.swift
//
//  Copyright (c) 2017 Bob Brown and Tom Davidsmeier. All Rights Reserved.
//  All the good stuff is by Thomas Davidsmeier.
//  Bob Brown made all the parts that don't work.


import Foundation
import PlaygroundSupport
import UIKit

class MyViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    var labelStackView = UIStackView()
    var horizontalStackView = UIStackView()
    var verticalStackView = UIStackView()
    
    let classLabel = UILabel()
    let blankLabel = UILabel()
    let setupLabel = UILabel()
    
    let myView = UIView()
    let randomizeStudentsButton = UIButton(type: UIButtonType.roundedRect)
    let classPicker = UIPickerView()
    let setupPicker = UIPickerView()
    
    let myGrid = Grid(width: 75, height: 45, offset: CGPoint(x: 40, y: 110))
    
    let classes = ["Default", "Period 1", "Period 2","Period 3", "Period 4","Period 5", "Period 6","Period 7", "Period 8"]
    let classNames = ["default", "period1", "period2","period3", "period4","period5", "period6","period7", "period8"]
    
    let defaultNamesList = ["Robert","Bobby","Rob","Bobino","Bobaloo","Bob-bot","Thomas","Tommy","Thom","Tomaso","Tommy Boy","Tominator","Bobinator","TomTom","Tom","Bob"]
    
    let defaultSetupList = "empty"
    
    var setups = ["Default"]
    
    var studentLabels = [UILabel]()
    
    var currentClassName = "default"
    
    var currentSetupName = "Default"
    
    var currentNamesList = [String]()
    
    var currentSetupList = "empty"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        classLabel.text = "Class List"
        classLabel.textColor = .white
        classLabel.textAlignment = .center
        setupLabel.text = "Group List"
        setupLabel.textColor = .white
        setupLabel.textAlignment = .center
        
        myView.backgroundColor = .black
        
        classPicker.frame = CGRect(x: 5, y: 5, width: 180, height: 60)
        classPicker.delegate = self
        classPicker.backgroundColor = .orange
        
        setupPicker.frame = CGRect(x: 305, y: 5, width: 180, height: 60)
        setupPicker.delegate = self
        setupPicker.backgroundColor = .orange
        
        randomizeStudentsButton.frame = CGRect(x: 185, y: 5, width: 130, height: 60)
        randomizeStudentsButton.backgroundColor = .white
        randomizeStudentsButton.setTitleColor(.orange, for: .normal)
        randomizeStudentsButton.setTitle("Randomize!", for: [])
        randomizeStudentsButton.titleLabel?.font = UIFont(name: "Times", size: 25.0)
        randomizeStudentsButton.addTarget(self, action: #selector(randomizeStudentsButtonHandler), for: .touchUpInside)
        
        currentNamesList = defaultNamesList
        currentSetupList = defaultSetupList
        
        //Set up fake names for the default class.
        var playgroundValueArray = [PlaygroundValue]()
        for name in currentNamesList
        {
            playgroundValueArray.append(PlaygroundValue.string(name))
        }
        
        PlaygroundKeyValueStore.current["default"] = PlaygroundValue.array(playgroundValueArray)
        
        
        //Set up fake group for the default class.array
        
        var playgroundValueDictionary = [String:PlaygroundValue]()
        
        playgroundValueDictionary[currentSetupName] = PlaygroundValue.string(currentSetupList)
        PlaygroundKeyValueStore.current[currentClassName + "Groups"] = PlaygroundValue.dictionary(playgroundValueDictionary)
        
        LoadStudents()
        ArrangeSetup()
        
        //Adding all the subviews.
        
        myView.addSubview(randomizeStudentsButton)
        
        self.view.addSubview(myView)
        self.view.addSubview(classPicker)
        self.view.addSubview(setupPicker)
        myView.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        myView.heightAnchor.constraint(equalTo: self.view.heightAnchor).isActive = true
        myView.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        myView.topAnchor.constraint(equalTo: self.view.topAnchor).isActive = true
        randomizeStudentsButton.rightAnchor.constraint(equalTo: myView.rightAnchor, constant: -5).isActive = true
        randomizeStudentsButton.bottomAnchor.constraint(equalTo: myView.bottomAnchor, constant: -5).isActive = true
        randomizeStudentsButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        randomizeStudentsButton.heightAnchor.constraint(equalToConstant: 80).isActive = true
        
        for i in studentLabels.indices {
            myView.addSubview(studentLabels[i])
        }
        
        labelStackView = UIStackView(arrangedSubviews: [classLabel,blankLabel,setupLabel])
        labelStackView.distribution = .fillEqually
        labelStackView.alignment = .center
        
        
        horizontalStackView = UIStackView(arrangedSubviews: [classPicker, randomizeStudentsButton, setupPicker])
        horizontalStackView.distribution = .fillEqually
        horizontalStackView.spacing = 5
        
        verticalStackView = UIStackView(arrangedSubviews: [labelStackView,horizontalStackView,myView])
        verticalStackView.axis = .vertical
        verticalStackView.distribution = .fill
        verticalStackView.contentMode = .center
        
        verticalStackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(verticalStackView)
        
        NSLayoutConstraint.activate([
            verticalStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            verticalStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            verticalStackView.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            verticalStackView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant:0)
            ])
        
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let label = UILabel()
        label.font = UIFont(name: "Times", size: 30.0)
        label.textAlignment = .center
        label.textColor = .white
        if pickerView == classPicker
        {
            label.text = classes[row]
        }
        else
        {
            label.text = setups[row]
        }
        
        return label
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 25.0
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        SaveSetupToFile()
        
        if pickerView == classPicker {
            
            currentClassName = classNames[row]
            
            LoadStudents()
            populateSetupPickerFromFileList()
            ArrangeSetup()
            
        }
        
        if pickerView == setupPicker {
            
            currentSetupName = setups[row]
            ArrangeSetup()
        }
        //debug()
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == classPicker {
            return classes.count
        } else {
            return setups.count
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == classPicker {
            return classes[row]
        } else {
            return setups[row]
        }
    }
    
    func randomizeStudentsButtonHandler() {
        randomizeStudents(0)
    }
    
    func randomizeStudents(_ howManyTimesIHaveRun: Int) {
        var initialStudentList = [String]()
        var randomizedStudentList = [String]()
        
        for i in studentLabels.indices {
            initialStudentList.append(studentLabels[i].text!)
        }
        
        while initialStudentList.count != 0 {
            let randomNumber = Int(arc4random_uniform(UInt32(initialStudentList.count)))
            randomizedStudentList.append(initialStudentList.remove(at: randomNumber))
        }
        
        for i in studentLabels.indices {
            studentLabels[i].text = randomizedStudentList[i]
        }
        if howManyTimesIHaveRun < 20 {
            
            
            
//            if SeatTogether("Bobby", "Tommy") ||
//                KeepApart("Bobby", "Thom")
//            {
//                randomizeStudents(howManyTimesIHaveRun+1)
//            }
            
        }
        
        if howManyTimesIHaveRun == 0 {
            SaveSetupToFile()
        }
    }
    
    func SaveSetupToFile() {
        currentSetupList = String()
        for i in studentLabels.indices {
            let s = studentLabels[i]
            var setup = s.text! + ";"
            setup += String(describing: myGrid.gridX(s.center))+";"
            setup += String(describing: myGrid.gridY(s.center))+"/"
            currentSetupList.append(setup)
        }
        
        var updatedPlaygroundValueDictionary = [String:PlaygroundValue]()
        
        if let keyValue = PlaygroundKeyValueStore.current[currentClassName + "Groups"], case .dictionary(let names) = keyValue {
            
            for (groupName, var data) in names {
                if groupName == currentSetupName
                {
                    data = PlaygroundValue.string(currentSetupList)
                }
                updatedPlaygroundValueDictionary[groupName] = data
            }
            PlaygroundKeyValueStore.current[currentClassName + "Groups"] = PlaygroundValue.dictionary(updatedPlaygroundValueDictionary)
        }
    }
    
    //Such a drag man.  Drag handling functions.
    func makeDraggable(myView: UIView) {
        let myGesture = UIPanGestureRecognizer(target: self, action: #selector(MyViewController.wasDragged(_ :)))
        
        myView.addGestureRecognizer(myGesture)
        myView.isUserInteractionEnabled = true
    }
    
    func wasDragged(_ gesture: UIPanGestureRecognizer) {
        let translation = gesture.translation(in: self.view)
        let whatWasDragged = gesture.view!
        
        
        whatWasDragged.center = CGPoint(x: whatWasDragged.center.x + translation.x, y: whatWasDragged.center.y + translation.y)
        
        if gesture.state == .ended{
            whatWasDragged.center = myGrid.snapThisPointToMe(whatWasDragged.center)
            SaveSetupToFile()
        }
        
        gesture.setTranslation(CGPoint.zero, in: self.view)
    }
    
    func SeatTogether(_ student1: String, _ student2: String) -> Bool {
        var point1 = CGPoint(x: -1000, y:-1000)
        var point2 = CGPoint(x: -1000, y: -1000)
        
        for i in studentLabels.indices {
            if studentLabels[i].text == student1 { point1 = studentLabels[i].center }
            if studentLabels[i].text == student2 { point2 = studentLabels[i].center }
        }
        if (point2.x == -1000) && point1.x == -1000 {
            return false
        } else if (abs(myGrid.gridX(point1)-myGrid.gridX(point2)) <= 1) && (abs(myGrid.gridY(point1)-myGrid.gridY(point2)) <= 1){
            return true} else {
            return false
        }
    }
    
    func KeepApart(_ student1: String, _ student2: String) -> Bool {
        var point1 = CGPoint(x: -1000, y:-1000)
        var point2 = CGPoint(x: -1000, y: -1000)
        
        for i in studentLabels.indices {
            if studentLabels[i].text == student1 { point1 = studentLabels[i].center }
            if studentLabels[i].text == student2 { point2 = studentLabels[i].center }
        }
        if (point2.x == -1000) && point1.x == -1000 {
            return true
        } else if (abs(myGrid.gridX(point1)-myGrid.gridX(point2)) <= 1) && (abs(myGrid.gridY(point1)-myGrid.gridY(point2)) <= 1){
            return false} else {
            return true
        }
    }
    
    func LoadStudents() {
        
        currentNamesList = [String]()
        
        if let keyValue = PlaygroundKeyValueStore.current[currentClassName],
            case .array(let names) = keyValue {
            for name in names {
                if case .string(let babyKeyValue) = name {
                    currentNamesList.append("\(babyKeyValue)")
                }
            }
        }
        
        for i in studentLabels.indices {
            studentLabels[i].removeFromSuperview()
        }
        
        studentLabels = [UILabel]()
        
        for i in currentNamesList.indices {
            studentLabels.append(makeStudentLabel(student: currentNamesList[i]))
        }
        
        for i in studentLabels.indices {
            myView.addSubview(studentLabels[i])
        }
    }
    
    func ArrangeSetup() {
        
        currentClassName = classNames[classPicker.selectedRow(inComponent: 0)]
        currentSetupName = setups[setupPicker.selectedRow(inComponent: 0)]
        
        if let keyValue = PlaygroundKeyValueStore.current[currentClassName + "Groups"], case .dictionary(let names) = keyValue {
            
            for (groupName, data) in names {
                if groupName == currentSetupName
                {
                    if case .string(var newData) = data {
                        if newData == "" {
                            let dimension = Int(floor(sqrt(Double(studentLabels.count)))+2)
                            for i in studentLabels.indices {
                                var newX: Int = i / dimension
                                var newY: Int = i % dimension
                                studentLabels[i].center = myGrid.snapThisToMyGridPoint(gridX: newX, gridY: newY)
                                newData += "\(studentLabels[i].text);\(newX);\(newY)/"
                            }
                        }
                        currentSetupList = newData
                    }
                }
            }
        }
        else
        {
            
            currentSetupList = "empty"
            currentSetupName = "Default"
            
            var playgroundValueDictionary = [String:PlaygroundValue]()
            
            playgroundValueDictionary[currentSetupName] = PlaygroundValue.string(currentSetupList)
            PlaygroundKeyValueStore.current[currentClassName + "Groups"] = PlaygroundValue.dictionary(playgroundValueDictionary)
        }
        
        if currentSetupList == "empty"
        {
            let dimension = Int(floor(sqrt(Double(studentLabels.count)))+2)
            for i in studentLabels.indices {
                studentLabels[i].center = myGrid.snapThisToMyGridPoint(gridX: i / dimension, gridY: i % dimension)
            }
            return
        }

        var currentSetupListArray = currentSetupList.components(separatedBy: "/")
        currentSetupListArray.popLast()

        for i in currentSetupListArray.indices {
            let studentSetup = currentSetupListArray[i].components(separatedBy: ";")
            
            for i in studentLabels.indices {
                if studentSetup[0] == studentLabels[i].text {
                    studentLabels[i].center = CGPoint(x: myGrid.screenX(Int(studentSetup[1])!), y: myGrid.screenY(Int(studentSetup[2])!))
                }
            }
        }
    }
    
    
    func debug(_ msgNum :String)
    {
        let message = msgNum + "\(currentClassName)\n\(currentNamesList)\n\(currentSetupName)\n\(currentSetupList)"
        
        let alert = UIAlertController(title: "Arrange Setup", message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) in
            
        })
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
        
    }
    
    func makeStudentLabel(student: String) -> UILabel {
        let studentLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 70, height: 40))
        
        studentLabel.text = student
        studentLabel.backgroundColor = UIColor.white.withAlphaComponent(0.7)
        studentLabel.font = UIFont.systemFont(ofSize: 12.0)
        studentLabel.adjustsFontSizeToFitWidth = true
        studentLabel.numberOfLines = 2
        studentLabel.lineBreakMode = .byWordWrapping
        studentLabel.textAlignment = NSTextAlignment.center
        makeDraggable(myView: studentLabel)
        return studentLabel
    }
    
    func populateSetupPickerFromFileList() {
        setups = [String]()
        
        currentClassName = classNames[classPicker.selectedRow(inComponent: 0)]
        
        if let keyValue = PlaygroundKeyValueStore.current[currentClassName + "Groups"], case .dictionary(let names) = keyValue {
            
            for (groupName, _) in names {
                setups.append(groupName)
            }
        }
        
        if setups.count == 0 {
            setups = ["Default"]
        }
        
        setupPicker.reloadAllComponents()
    }
}

PlaygroundPage.current.liveView = MyViewController()
