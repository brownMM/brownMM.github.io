/*:
 
 # To Select a Class Period
 - Use the Class List PickerView at the top Left
 */
//: ![Picker](Combo.png)
/*:
 # To Select a Group within a Period
 - Use the Group List PickerView at the top Right
 */
//: ![Picker](Combo2.png)
/*:
 # To Move a Student
 - Press on a student and drag to the desired location
 # To Randomize Seats
 - Tap the Randomize button at the center of the screen
 - **Warning**: hitting Randomize! does not save the previous view
 # To Make Full Screen
 - Press and hold your finger in the middle of the screen
 - Drag to make Full Screen
 */
//: ![Screen Shots](Combo3.png)
/*:
 - To return to the instructions, press and hold your finger at the edge of the screen
 - Drag to make half screen
 */

//: Copyright (c) 2017
//: Bob Brown and Tom Davidsmeier. All Rights Reserved.
//: All the good stuff is by Thomas Davidsmeier.
//: Bob Brown made all the parts that don't work.
