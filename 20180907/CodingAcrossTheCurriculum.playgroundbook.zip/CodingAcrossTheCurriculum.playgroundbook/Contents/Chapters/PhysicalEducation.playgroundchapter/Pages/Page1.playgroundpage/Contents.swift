//#-hidden-code

import UIKit
import CoreBluetooth
import PlaygroundSupport
import AVFoundation

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    var manager:CBCentralManager!
    var peripheral:CBPeripheral!
    var label: UILabel!
    var bandNumberTextField: UITextField!
    var button: UIButton!
    var heartRate: UInt16 = 0
    var device: String!
    var ageTextField: UITextField!
    var maxHeartRate: Double!
    var player:AVAudioPlayer = AVAudioPlayer()
    var currentValue = 0
    var imageView:UIImageView!
    
    let HEART_RATE_SERVICE  = "180D"
    let HEART_RATE_MEASUREMENT = "2A37"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let numberLabel = UILabel(frame: CGRect(x: 10, y: 10, width: 120, height: 30))
        numberLabel.text = "Band Number:"
        numberLabel.textColor = UIColor.white
        view.addSubview(numberLabel)
        bandNumberTextField = UITextField(frame: CGRect(x: 130, y: 10, width: 100, height: 30))
        bandNumberTextField.backgroundColor = UIColor.white
        bandNumberTextField.textColor = UIColor.black
        view.addSubview(bandNumberTextField)
        let ageLabel = UILabel(frame: CGRect(x: 10, y: 50, width: 120, height: 30))
        ageLabel.text = "Age:"
        ageLabel.textColor = UIColor.white
        view.addSubview(ageLabel)
        ageTextField = UITextField(frame: CGRect(x: 130, y: 50, width: 60, height: 30))
        ageTextField.backgroundColor = UIColor.white
        ageTextField.textColor = UIColor.black
        view.addSubview(ageTextField)
        
        label = UILabel(frame: CGRect(x: 65, y: 300, width: 300, height: 300))
        label.backgroundColor = UIColor.white
        label.textColor = UIColor.black
        label.font = UIFont(name: "Times", size: 180)
        label.textAlignment = .center
        view.addSubview(label)
        button = UIButton(frame: CGRect(x: 250, y: 30, width: 100, height: 30))
        button.setTitle("Connect", for: .normal)
        view.addSubview(button)
        button.addTarget(self, action: #selector(whenButtonPressed), for: .touchUpInside)
        
        //        imageView = UIImageView(frame: CGRect(x: 150, y: 120, width: 150, height: 150))
        //        imageView.backgroundColor = UIColor.white
        //        view.addSubview(imageView)
        
        
    }
    
    func whenButtonPressed()
    {
        device = bandNumberTextField.text!
        maxHeartRate = 220.0 - Double(ageTextField.text!)!
        manager = CBCentralManager(delegate: self, queue: nil)
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            central.scanForPeripherals(withServices: nil, options: nil)
            
        } else {
            print("Bluetooth not available.")
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let device = (advertisementData as NSDictionary)
            .object(forKey: CBAdvertisementDataLocalNameKey)
            as? NSString
        
        if device?.contains("Polar") == true {
            if (peripheral.name?.contains(device as! String))!
            {
                self.manager.stopScan()
                button.setTitle("Connected", for: .normal)
                self.peripheral = peripheral
                self.peripheral.delegate = self
                
                manager.connect(peripheral, options: nil)
                
                let path = Bundle.main.url(forResource: "Rocky", withExtension: "mp3")
                do {
                    player = try AVAudioPlayer(contentsOf: path!)
                }catch {
                    
                }
                player.prepareToPlay()
                player.play()

            }
            
        }
        
    }
    
    func centralManager(_ central: CBCentralManager, didConnect aPeripheral: CBPeripheral) {
        aPeripheral.delegate = self
        // NOTE you might only discover HR service, but on this example we discover all services
        aPeripheral.discoverServices(nil)
    }
    
    
    func peripheral(_ aPeripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if !(error != nil) {
            for aService: CBService in aPeripheral.services! {
                if aService.uuid.isEqual(CBUUID(string: HEART_RATE_SERVICE)) {
                    label.text = "Here"
                    aPeripheral.discoverCharacteristics(nil, for: aService)
                }
            }
        }
    }
    
    func peripheral(_ aPeripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if !(error != nil) {
            if service.uuid.isEqual(CBUUID(string: HEART_RATE_SERVICE)) {
                for aChar: CBCharacteristic in service.characteristics! {
                    if aChar.uuid.isEqual(CBUUID(string: HEART_RATE_MEASUREMENT)) {
                        aPeripheral.setNotifyValue(true, for: aChar)
                    }
                }
            }
        }
    }
    
    func peripheral(_ aPeripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if !(error != nil) {
            if characteristic.uuid.isEqual(CBUUID(string: HEART_RATE_MEASUREMENT))
            {
                
                //var bpm: UInt16 = 0
                characteristic.value?.withUnsafeBytes {(reportData: UnsafePointer<UInt8>)->Void in
                    if reportData[0] & 0x01 == 0 {
                        heartRate = UInt16(reportData[1])
                    } else {
                        //bpm = UInt16(littleEndian: UInt16(UnsafePointer<UInt32>(reportData + 1).pointee))
                    }
                }
                
            }
        }
        
        label.text = "\(heartRate)"
        let currentHeartRate = Double(heartRate)
        //#-code-completion(everything, hide)
        //#-code-completion(identifier, show, currentHeartRate, maxHeartRate)
        //#-code-completion(identifier, show, slowDown())
        //#-code-completion(identifier, show, keepPace())
        //#-code-completion(identifier, show, speedUp())
        //#-end-hidden-code
//: If your **currentHeartRate** is more than 85% of your **maximumHeartRate**, you should slow down. If your **currentHeartRate** is more than 50% of your **maximumHeartRate**, you should keep going the same pace. If your **currentHeartRate** is less then 50% of your **maximumHeartRate**, you should speed up.
if <#Variable#> > 0.0 * <#Variable#>
{
    <#Function#>
}
else if <#Variable#>  > 0.0 * <#Variable#>
{
    <#Function#>
}
else
{
    <#Function#>
}
        
        //#-hidden-code
        
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        central.scanForPeripherals(withServices: nil, options: nil)
        
    }
    
    func slowDown()
    {
        if view.backgroundColor != UIColor.red
        {
            view.backgroundColor = UIColor.red
            
            let path = Bundle.main.url(forResource: "RockabyeBaby", withExtension: "mp3")
            do {
                player = try AVAudioPlayer(contentsOf: path!)
            }catch {
                
            }
            player.prepareToPlay()
            player.play()
        }
    }
    
    func keepPace()
    {
        if view.backgroundColor != UIColor.green
        {
            view.backgroundColor = UIColor.green
            
            let path = Bundle.main.url(forResource: "DontStop", withExtension: "m4a")
            do {
                player = try AVAudioPlayer(contentsOf: path!)
            }catch {
                
            }
            player.prepareToPlay()
            player.play()
        }
    }
    
    func speedUp()
    {
        if view.backgroundColor != UIColor.black
        {
            view.backgroundColor = UIColor.black
            
            let path = Bundle.main.url(forResource: "Rocky", withExtension: "mp3")
            do {
                player = try AVAudioPlayer(contentsOf: path!)
            }catch {
                
            }
            player.prepareToPlay()
            player.play()
        }
    }
    
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
