//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    var imageView = UIImageView(frame: CGRect(x: 0, y: 100, width: 432, height: 432))
    var button300 = UIButton(frame: CGRect(x: 10, y: 10, width: 100, height: 50))
    var button96 = UIButton(frame: CGRect(x: 160, y: 10, width: 100, height: 50))
    var button72 = UIButton(frame: CGRect(x: 310, y: 10, width: 100, height: 50))
    var pinch: UIPinchGestureRecognizer!
    
    override func viewDidLoad() {
        
        button300.setTitle("300ppi", for: .normal)
        button96.setTitle("96ppi", for: .normal)
        button72.setTitle("72ppi", for: .normal)
        button300.backgroundColor = UIColor.orange
        button96.backgroundColor = UIColor.orange
        button72.backgroundColor = UIColor.orange
        
        button300.addTarget(self, action: #selector(determineButtonPressed), for: .touchUpInside)
        button96.addTarget(self, action: #selector(determineButtonPressed), for: .touchUpInside)
        button72.addTarget(self, action: #selector(determineButtonPressed), for: .touchUpInside)
        view.addSubview(button300)
        view.addSubview(button96)
        view.addSubview(button72)
        
        pinch = UIPinchGestureRecognizer(target: self, action: #selector(scaleImage))
        view.addGestureRecognizer(pinch)
        view.addSubview(imageView)
    }
    
    func determineButtonPressed(_ sender: UIButton)
    {
        let TheButtonTitle = sender.titleLabel!.text!
        //#-code-completion(everything, hide)
        //#-code-completion(identifier, show, TheButtonTitle)
        //#-code-completion(identifier, show, display300ppiImage())
        //#-code-completion(identifier, show, display96ppiImage())
        //#-code-completion(identifier, show, display72ppiImage())
//#-end-hidden-code
//: If **TheButtonTitle** is "300ppi", then call the function named **display300ppiImage()**. If **TheButtonTitle** is "96ppi", then call the function named **display96ppiImage()**. If anything else, then call the function named **display72ppiImage()**.
        
if <#Variable#> == "<#String#>"
{
    <#Function Call#>
}
else if <#Variable#> == "<#String#>"
{
    <#Function Call#>
}
else
{
    <#Function Call#>
}
    
//#-hidden-code

    }
    
    func scaleImage(_ sender: UIPinchGestureRecognizer) {
        self.imageView.transform = self.imageView.transform.scaledBy(x: sender.scale, y: sender.scale)
        sender.scale = 1
    }
    
    func display300ppiImage()
    {
        imageView.image = UIImage(named: "Pic300")
    }
    
    func display96ppiImage()
    {
        imageView.image = UIImage(named: "Pic96")
    }
    
    func display72ppiImage()
    {
        imageView.image = UIImage(named: "Pic72")
    }
    
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

