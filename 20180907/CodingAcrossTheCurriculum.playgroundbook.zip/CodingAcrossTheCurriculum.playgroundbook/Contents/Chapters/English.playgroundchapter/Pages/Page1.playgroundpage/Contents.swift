import UIKit
import PlaygroundSupport





class ViewController : UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    var pickerViewPrefixes = UIPickerView()
    var pickerViewRoots = UIPickerView()
    var possibleWordOutput = UILabel()
    var definitionOutput = UILabel()
    var selectedRoot = ""
    var selectedPrefix = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        //Behavior of Display: When pickers are interacted with, that triggers the change in the displays of the possible word, the word
        //Setting up pickers
        
        pickerViewPrefixes = UIPickerView(frame: CGRect(x: 10, y: 10, width: 200, height: 100))
        pickerViewPrefixes.dataSource = self
        pickerViewPrefixes.delegate = self
        pickerViewPrefixes.backgroundColor = UIColor.white
        
        self.view.addSubview(pickerViewPrefixes)
        
        pickerViewRoots = UIPickerView(frame: CGRect(x: 170, y: 10, width: 200, height: 100))
        pickerViewRoots.dataSource = self
        pickerViewRoots.delegate = self
        pickerViewRoots.backgroundColor = UIColor.white
        
        self.view.addSubview(pickerViewRoots)
        
        //Setting up labels to hold output
        possibleWordOutput = UILabel(frame: CGRect(x: 50, y: 250, width: 230, height: 50))
        possibleWordOutput.backgroundColor = UIColor.white
        possibleWordOutput.textAlignment = NSTextAlignment(rawValue: 1)!
        
        self.view.addSubview(possibleWordOutput)
        
    }
    
    var roots = ["", "-tract", "-gress"]
    
    var prefixes = ["", "re-", "pro-", "con-"]
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == pickerViewRoots {
            return roots.count
        }else{
            return prefixes.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == pickerViewRoots {
            return roots[row]
        }else{
            return prefixes[row]
        }
        
    }
    
    func pickerView(_ pickerView:UIPickerView, didSelectRow: Int, inComponent: Int) {
        var word = ""
        var root = ""
        var prefix = ""
        
        if pickerView == pickerViewRoots {
            selectedRoot = roots[didSelectRow]
        } else {
            selectedPrefix = prefixes[didSelectRow]
        }
        root = String(selectedRoot.characters.dropFirst())
        prefix = String(selectedPrefix.characters.dropLast())
        word = prefix + root
        
        possibleWordOutput.text = word
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
}
//let pickerData = RootsPickerData()
//let pickerView = UIPickerView()
//pickerView.dataSource = pickerData
//pickerView.delegate = pickerData
//pickerView.backgroundColor = UIColor.white

// Show in playground timeline
PlaygroundPage.current.liveView = ViewController()

