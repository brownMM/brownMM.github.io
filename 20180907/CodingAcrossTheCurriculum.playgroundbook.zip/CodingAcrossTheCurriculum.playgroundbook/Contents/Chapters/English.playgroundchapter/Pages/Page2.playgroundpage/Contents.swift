//#-hidden-code
import UIKit
import PlaygroundSupport
import MessageUI

class Resource
{
    var authorOrEditor: String?
    var title: String?
}

class Database: Resource
{
    var originalSource: String?
    var dababaseName: String?
    var datePublished: String?
    var dateAccessed: String?
    var companyName: String?
    var paragraph: String?
}

class Book: Resource
{
    var publisher: String?
    var cityPublished: String?
    var datePublished: String?
    var pageNumber: String?
    var isbnNumber: String?
}

class Website: Resource
{
    var sponsor: String?
    var nameOfWebsite: String?
    var datePosted: String?
    var dateAccessed: String?
    var paragraph: String?
}

class ViewController: UIViewController, MFMailComposeViewControllerDelegate,UIPickerViewDataSource, UIPickerViewDelegate
{
    var scrollView = UIScrollView(frame: CGRect(x: 0, y: 0, width: 435, height: 650))
    var contentView = UIView(frame: CGRect(x: 0, y: 0, width: 435, height: 1000))
    var segmentedController = UISegmentedControl(frame: CGRect(x: 30, y: 10, width: 370, height: 40))
    var updateButton = UIButton(frame: CGRect(x: 10, y: 590, width: 100, height: 25))
    var finishedButton = UIButton(frame: CGRect(x: 320, y: 590, width: 100, height: 25))
    var label1 = UILabel(frame: CGRect(x: 5, y: 50, width: 350, height: 30))
    var textField2 = UITextField(frame: CGRect(x: 30, y: 70, width: 350, height: 30))
    var label3 = UILabel(frame: CGRect(x: 5, y: 100, width: 350, height: 30))
    var textField4 = UITextField(frame: CGRect(x: 30, y: 120, width: 350, height: 30))
    var label5 = UILabel(frame: CGRect(x: 5, y: 150, width: 350, height: 30))
    var textField6 = UITextField(frame: CGRect(x: 30, y: 170, width: 350, height: 30))
    var label7 = UILabel(frame: CGRect(x: 5, y: 200, width: 350, height: 30))
    var textField8 = UITextField(frame: CGRect(x: 30, y: 220, width: 350, height: 30))
    var label9 = UILabel(frame: CGRect(x: 5, y: 250, width: 350, height: 30))
    var textField10 = UITextField(frame: CGRect(x: 30, y: 270, width: 350, height: 30))
    var label11 = UILabel(frame: CGRect(x: 5, y: 300, width: 350, height: 30))
    var textField12 = UITextField(frame: CGRect(x: 30, y: 320, width: 350, height: 30))
    var label13 = UILabel(frame: CGRect(x: 5, y: 350, width: 350, height: 30))
    var textField14 = UITextField(frame: CGRect(x: 30, y: 370, width: 350, height: 30))
    var label15 = UILabel(frame: CGRect(x: 5, y: 430, width: 350, height: 30))
    var companyPicker = UIPickerView(frame: CGRect(x: 0, y: 440, width: 400, height: 70))
    var databasePicker = UIPickerView(frame: CGRect(x: 0, y: 360, width: 400, height: 70))
    
    var bookArray = [Book]()
    var webSiteArray = [Website]()
    var databaseArray = [Database]()
    var output = ""
    var databases = [String]()
    var companies = [String]()
    var database = String()
    var company = String()
    var resourceArray = [Resource]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        segmentedController.insertSegment(withTitle: "Book", at: 0, animated: false)
        segmentedController.insertSegment(withTitle: "Website", at: 1, animated: false)
        segmentedController.insertSegment(withTitle: "Database", at: 2, animated: false)
        segmentedController.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        segmentedController.tintColor = UIColor.orange
        contentView.addSubview(segmentedController)
        
        updateButton.setTitle("Update", for: .normal)
        updateButton.backgroundColor = UIColor.orange
        updateButton.addTarget(self, action: #selector(updateButtonPressed), for: .touchUpInside)
        contentView.addSubview(updateButton)
        
        finishedButton.setTitle("Finished", for: .normal)
        finishedButton.backgroundColor = UIColor.orange
        finishedButton.addTarget(self, action: #selector(finishedButtonPressed), for: .touchUpInside)
        contentView.addSubview(finishedButton)
        
        label1.font = UIFont(name: "Times", size: 10.0)
        label3.font = UIFont(name: "Times", size: 10.0)
        label5.font = UIFont(name: "Times", size: 10.0)
        label7.font = UIFont(name: "Times", size: 10.0)
        label9.font = UIFont(name: "Times", size: 10.0)
        label11.font = UIFont(name: "Times", size: 10.0)
        label13.font = UIFont(name: "Times", size: 10.0)
        label15.font = UIFont(name: "Times", size: 10.0)
        
        contentView.addSubview(label1)
        contentView.addSubview(textField2)
        contentView.addSubview(label3)
        contentView.addSubview(textField4)
        contentView.addSubview(label5)
        contentView.addSubview(textField6)
        contentView.addSubview(label7)
        contentView.addSubview(textField8)
        contentView.addSubview(label9)
        contentView.addSubview(textField10)
        contentView.addSubview(label11)
        contentView.addSubview(textField12)
        contentView.addSubview(label13)
        contentView.addSubview(textField14)
        contentView.addSubview(label15)
        
        databases = ["Biography in Context","Global Issues in Context","Opposing Viewpoints", "Country Reports", "World Book Encyclopedia","EBSCO","CQ Researcher", "Science in Context", "Student Resource in Context","Infotrac","World Geography","SIRS","FirstSearch"]
        
        companies = ["ABC-CLIO", "Gale Group", "Greenhaven Press", "JSTOR", "InfoTrac", "SIRS Researcher", "CQ Researcher","St. James Press","U*X*L*","eLibrary"]
        
        
        companyPicker.dataSource = self
        companyPicker.delegate = self
        self.contentView.addSubview(companyPicker)
        
        databasePicker.dataSource = self
        databasePicker.delegate = self
        self.contentView.addSubview(databasePicker)
        
        scrollView.contentSize = CGSize(width: 435, height: 1400)
        scrollView.addSubview(contentView)
        view.addSubview(scrollView)
        
        companyPicker.alpha = 0
        databasePicker.alpha = 0
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == companyPicker
        {
            return companies.count
        }
        else
        {
            return databases.count
        }
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == companyPicker
        {
            return companies[row]
        }
        else
        {
            return databases[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == companyPicker
        {
            company = companies[row]
        }
        else
        {
            database = databases[row]
        }
    }
    
    func segmentChanged()
    {
        let Book = 0
        let Website = 1
        
        //#-code-completion(everything, hide)
        //#-code-completion(identifier, show, Book, Website)
        //#-code-completion(identifier, show, displayBookPage())
        //#-code-completion(identifier, show, displayWebsitePage())
        //#-code-completion(identifier, show, displayDatabasePage())
        //#-end-hidden-code
//: If **Book** is selected, then **displayBookPage()**. If **Website** is selected, then **displayWebsitePage()**. If none of the above are selected, **displayDatabasePage()**.
        
if youSelect(<#Variable#>)
{
    <#Function#>
}
else if youSelect(<#Variable#>)
{
    <#Function#>
}
else
{
    <#Function#>
}
        
        //#-hidden-code
        //        if youSelect(Book)
        //        {
        //            displayBookPage()
        //        }
        //        else if youSelect(Website)
        //        {
        //            displayWebsitePage()
        //        }
        //        else
        //        {
        //            displayDatabasePage()
        //        }
    }
    
    func displayBookPage()
    {
        textField2.text = ""
        textField4.text = ""
        textField6.text = ""
        textField8.text = ""
        textField10.text = ""
        textField12.text = ""
        textField14.text = ""
        
        textField2.alpha = 1
        textField4.alpha = 1
        textField6.alpha = 1
        textField8.alpha = 1
        textField10.alpha = 1
        textField12.alpha = 1
        textField14.alpha = 1
        companyPicker.alpha = 0
        databasePicker.alpha = 0
        
        label1.text = "Author or Editor:"
        label3.text = "Title:"
        label5.text = "Publisher:"
        label7.text = "City Published (if more than one, city closet to Chicago)"
        label9.text = "Date Published:"
        label11.text = "Page#"
        label13.text = "ISBN:"
        label15.text = ""
        
        textField2.backgroundColor = UIColor.lightGray
        textField4.backgroundColor = UIColor.lightGray
        textField6.backgroundColor = UIColor.lightGray
        textField8.backgroundColor = UIColor.lightGray
        textField10.backgroundColor = UIColor.lightGray
        textField12.backgroundColor = UIColor.lightGray
        textField14.backgroundColor = UIColor.lightGray
    }
    
    func displayWebsitePage()
    {
        textField2.text = ""
        textField4.text = ""
        textField6.text = ""
        textField8.text = ""
        textField10.text = ""
        textField12.text = ""
        textField14.text = ""
        
        textField2.alpha = 1
        textField4.alpha = 1
        textField6.alpha = 1
        textField8.alpha = 1
        textField10.alpha = 1
        textField12.alpha = 1
        textField14.alpha = 1
        companyPicker.alpha = 0
        databasePicker.alpha = 0
        
        label1.text = "Author or Editor (if provided):"
        label3.text = "Title of the website page (usually found at top center of page):"
        label5.text = "Sponsor of the website (usually found at the bottom of the website page):"
        label7.text = "Name of website (usually upper left corner of website):"
        label9.text = "Date posted, last updated, or copyright date:"
        label11.text = "Paragraph where you found the information"
        label13.text = "Date Accessed (today's date):"
        label15.text = ""
        
        textField2.backgroundColor = UIColor.lightGray
        textField4.backgroundColor = UIColor.lightGray
        textField6.backgroundColor = UIColor.lightGray
        textField8.backgroundColor = UIColor.lightGray
        textField10.backgroundColor = UIColor.lightGray
        textField12.backgroundColor = UIColor.lightGray
        textField14.backgroundColor = UIColor.lightGray
    }
    
    func displayDatabasePage()
    {
        textField2.text = ""
        textField4.text = ""
        textField6.text = ""
        textField8.text = ""
        textField10.text = ""
        textField12.text = ""
        textField14.text = ""
        
        textField2.alpha = 1
        textField4.alpha = 1
        textField6.alpha = 1
        textField8.alpha = 1
        textField10.alpha = 1
        textField12.alpha = 1
        textField14.alpha = 0
        companyPicker.alpha = 1
        databasePicker.alpha = 1
        
        label1.text = "Author or Editor (if provided):"
        label3.text = "Title of what you used:"
        label5.text = "Original Source (look at bottom of the webpage):"
        label7.text = "Date Published"
        label9.text = "Date Accessed (today's date):"
        label11.text = "Paragraph where you found the information"
        label13.text = "Name of Database(check one)"
        label15.text = "Name of Company(check one)"
        
        textField2.backgroundColor = UIColor.lightGray
        textField4.backgroundColor = UIColor.lightGray
        textField6.backgroundColor = UIColor.lightGray
        textField8.backgroundColor = UIColor.lightGray
        textField10.backgroundColor = UIColor.lightGray
        textField12.backgroundColor = UIColor.lightGray
        textField14.backgroundColor = UIColor.white
    }
    
    func youSelect(_ choice:Int) -> BooleanLiteralType
    {
        if choice == segmentedController.selectedSegmentIndex
        {
            return true
        }
        return false
    }
    
    func updateButtonPressed()
    {
        if segmentedController.selectedSegmentIndex == 0
        {
            let currentBook = Book()
            currentBook.authorOrEditor = textField2.text
            currentBook.title = textField4.text
            currentBook.publisher = textField6.text
            currentBook.cityPublished = textField8.text
            currentBook.datePublished = textField10.text
            currentBook.pageNumber = textField12.text
            currentBook.isbnNumber = textField14.text
            resourceArray.append(currentBook)
        }
        else if segmentedController.selectedSegmentIndex == 1
        {
            let currentWebsite = Website()
            currentWebsite.authorOrEditor = textField2.text
            currentWebsite.title = textField4.text
            currentWebsite.sponsor = textField6.text
            currentWebsite.nameOfWebsite = textField8.text
            currentWebsite.datePosted = textField10.text
            currentWebsite.dateAccessed = textField12.text
            currentWebsite.paragraph = textField14.text
            resourceArray.append(currentWebsite)
        }
        else
        {
            let currentDatabase = Database()
            currentDatabase.authorOrEditor = textField2.text
            currentDatabase.title = textField4.text
            currentDatabase.originalSource = textField6.text
            currentDatabase.datePublished = textField8.text
            currentDatabase.dateAccessed = textField10.text
            currentDatabase.paragraph = textField12.text
            currentDatabase.companyName = company
            currentDatabase.dababaseName = database
            resourceArray.append(currentDatabase)
        }
        
        textField2.text = ""
        textField4.text = ""
        textField6.text = ""
        textField8.text = ""
        textField10.text = ""
        textField12.text = ""
        textField14.text = ""
    }
    
    func finishedButtonPressed()
    {
        let sortedResourceArray = resourceArray.sorted { $0.authorOrEditor! < $1.authorOrEditor! }
        output = "                     Works Cited                       \n"
        
        for resource in sortedResourceArray
        {
            if let bookResource = resource as? Book
            {
                if bookResource.authorOrEditor != ""
                {
                    output += "\(bookResource.authorOrEditor!)."
                }
                if bookResource.title != ""
                {
                    output += "\(bookResource.title!)."
                }
                if bookResource.cityPublished != ""
                {
                    output += "\(bookResource.cityPublished!):"
                }
                if bookResource.publisher != ""
                {
                    output += "\(bookResource.publisher!),"
                }
                if bookResource.datePublished != ""
                {
                    output += "\(bookResource.datePublished!):"
                }
                if bookResource.pageNumber != ""
                {
                    output += "\(bookResource.pageNumber!)."
                }
                output += "\n\n"
            }
            else if let webSiteResource = resource as? Website
            {
                if webSiteResource.authorOrEditor != ""
                {
                    output += "\(webSiteResource.authorOrEditor!)."
                }
                if webSiteResource.title != ""
                {
                    output += "\(webSiteResource.title!)."
                }
                if webSiteResource.sponsor != ""
                {
                    output += "\(webSiteResource.sponsor!):"
                }
                if webSiteResource.nameOfWebsite != ""
                {
                    output += "\(webSiteResource.nameOfWebsite!),"
                }
                if webSiteResource.datePosted != ""
                {
                    output += "\(webSiteResource.datePosted!):"
                }
                if webSiteResource.dateAccessed != ""
                {
                    output += "\(webSiteResource.dateAccessed!)."
                }
                output += "\n\n"
            }
            else
            {
                let databaseResource = resource as! Database
                if databaseResource.authorOrEditor != ""
                {
                    output += "\(databaseResource.authorOrEditor!)."
                }
                if databaseResource.title != ""
                {
                    output += "\(databaseResource.title!)."
                }
                if databaseResource.originalSource != ""
                {
                    output += "\(databaseResource.originalSource!):"
                }
                if databaseResource.datePublished != ""
                {
                    output += "\(databaseResource.datePublished!),"
                }
                if databaseResource.dateAccessed != ""
                {
                    output += "\(databaseResource.dateAccessed!):"
                }
                if databaseResource.paragraph != ""
                {
                    output += "\(databaseResource.paragraph!)."
                }
                if databaseResource.dababaseName != ""
                {
                    output += "\(databaseResource.dababaseName!)."
                }
                if databaseResource.companyName != ""
                {
                    output += "\(databaseResource.companyName!)."
                }
                output += "\n\n"
            }
        }
        
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients(["bob.brown@d214.org"])
        mailComposerVC.setSubject("Works Cited")
        mailComposerVC.setMessageBody(output, isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertController(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", preferredStyle: .alert)
        present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
