//#-hidden-code

import UIKit
import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

class State{
    var name:String
    var electoralVotes:Int
    var bush_chaney_votes: Int
    var gore_liberman_votes: Int
    
    init(Name n:String, ElectoralVotes e:Int, Bush b:Int,Gore g:Int)
    {
        name = n
        electoralVotes = e
        bush_chaney_votes = b
        gore_liberman_votes = g
    }
}

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    var statePicker = UIPickerView()
    var states = [State]()
    var numberOfVotesLabel = UILabel()
    var stateBlocks = [UIView]()
    var myButton = UIButton()
    var textField1 = UITextField()
    var textField2 = UITextField()
    var totalDemocrat = 243
    var totalRepublican = 246
    var selectedRow = Int()
    var democratTotal = UILabel()
    var republicanTotal = UILabel()
    var numberOfDemocratVotes: Int!
    var numberOfRepublicanVotes: Int!
    var electoralVotes: Int!
    var currentState: String!
    var scene = SKScene(fileNamed: "Map.sks")
    var popularDemocratVoteTotal:Int = 45916042
    var popularRepublicanVoteTotal:Int = 45385203
    var popularDemocrateLabel = UILabel()
    var popularRepublicanLabel = UILabel()
    
    var mapView = SKView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.view.frame = CGRect(x: 0, y: 0, width: 400, height: 720)
        self.view.backgroundColor = UIColor.white
        
        
        states.append(State(Name: "Alabama", ElectoralVotes: 	9	,Bush:	941173	, Gore:	692611	))
        states.append(State(Name: "Alaska", ElectoralVotes: 	3	,Bush:	167398	, Gore:	79004	))
        states.append(State(Name: "Arizona", ElectoralVotes: 	8	,Bush:	781652	, Gore:	685341	))
        states.append(State(Name: "Arkansas", ElectoralVotes: 	11	,Bush:	472940	, Gore:	422768	))
        states.append(State(Name: "California", ElectoralVotes:	54	,Bush:	4567429	, Gore:	5861203	))
        states.append(State(Name: "Colorado", ElectoralVotes:	8	,Bush:	883748	, Gore:	738227	))
        states.append(State(Name: "Connecticut", ElectoralVotes:	8	,Bush:	561104	, Gore:	816659	))
        states.append(State(Name: "Delaware", ElectoralVotes:	3	,Bush:	137288	, Gore:	180068	))
        states.append(State(Name: "District of Columbia", ElectoralVotes:	3	,Bush:	18073	, Gore:	171923	))
        states.append(State(Name: "Florida", ElectoralVotes:	25	,Bush:	0	, Gore:	0	))
        states.append(State(Name: "Georgia", ElectoralVotes:	13	,Bush:	1419720	, Gore:	1116230	))
        states.append(State(Name: "Hawaii", ElectoralVotes:	4	,Bush:	137845	, Gore:	205286	))
        states.append(State(Name: "Idaho", ElectoralVotes:	4	,Bush:	336937	, Gore:	138637	))
        states.append(State(Name: "Illinois", ElectoralVotes:	22	,Bush:	2019421	, Gore:	2589026	))
        states.append(State(Name: "Indiana", ElectoralVotes:	12	,Bush:	1245836	, Gore:	901980	))
        states.append(State(Name: "Iowa", ElectoralVotes:	7	,Bush:	0	, Gore:	0	))
        states.append(State(Name: "Kansas", ElectoralVotes:	6	,Bush:	622332	, Gore:	399276	))
        states.append(State(Name: "Kentucky", ElectoralVotes:	8	,Bush:	872520	, Gore:	638923	))
        states.append(State(Name: "Louisiana", ElectoralVotes:	9	,Bush:	927871	, Gore:	792344	))
        states.append(State(Name: "Maine", ElectoralVotes:	4	,Bush:	286616	, Gore:	319951	))
        states.append(State(Name: "Maryland", ElectoralVotes:	10	,Bush:	813724	, Gore:	1143888	))
        states.append(State(Name: "Massachusetts", ElectoralVotes:	12	,Bush:	878502	, Gore:	1616487	))
        states.append(State(Name: "Michigan", ElectoralVotes:	18	,Bush:	1953139	, Gore:	2170418	))
        states.append(State(Name: "Minnesota", ElectoralVotes:	10	,Bush:	1109659	, Gore:	1168266	))
        states.append(State(Name: "Mississippi", ElectoralVotes:	7	,Bush:	572844	, Gore:	404614	))
        states.append(State(Name: "Missouri", ElectoralVotes:	11	,Bush:	1189924	, Gore:	1111138	))
        states.append(State(Name: "Montana", ElectoralVotes:	3	,Bush:	240178	, Gore:	137126	))
        states.append(State(Name: "Nebraska", ElectoralVotes:	5	,Bush:	433850	, Gore:	231776	))
        states.append(State(Name: "Nevada", ElectoralVotes:	4	,Bush:	301575	, Gore:	279978	))
        states.append(State(Name: "NewHampshire", ElectoralVotes:	4	,Bush:	273559	, Gore:	266348	))
        states.append(State(Name: "NewJersey", ElectoralVotes:	15	,Bush:	1284173	, Gore:	1788850	))
        states.append(State(Name: "NewMexico", ElectoralVotes:	5	,Bush:	0	, Gore:	0	))
        states.append(State(Name: "NewYork", ElectoralVotes:	33	,Bush:	2403374	, Gore:	4107697	))
        states.append(State(Name: "NorthCarolina", ElectoralVotes:	14	,Bush:	1631163	, Gore:	1257692	))
        states.append(State(Name: "NorthDakota", ElectoralVotes:	3	,Bush:	174852	, Gore:	95284	))
        states.append(State(Name: "Ohio", ElectoralVotes:	21	,Bush:	2350363	, Gore:	2183628	))
        states.append(State(Name: "Oklahoma", ElectoralVotes:	8	,Bush:	744337	, Gore:	474276	))
        states.append(State(Name: "Oregon", ElectoralVotes:	7	,Bush:	713577	, Gore:	720342	))
        states.append(State(Name: "Pennsylvania", ElectoralVotes:	23	,Bush:	2281127	, Gore:	2485967	))
        states.append(State(Name: "RhodeIsland", ElectoralVotes:	4	,Bush:	130555	, Gore:	249508	))
        states.append(State(Name: "SouthCarolina", ElectoralVotes:	8	,Bush:	786892	, Gore:	566037	))
        states.append(State(Name: "SouthDakota", ElectoralVotes:	3	,Bush:	190700	, Gore:	118804	))
        states.append(State(Name: "Tennessee", ElectoralVotes:	11	,Bush:	1061949	, Gore:	981720	))
        states.append(State(Name: "Texas", ElectoralVotes:	32	,Bush:	3799639	, Gore:	2433746	))
        states.append(State(Name: "Utah", ElectoralVotes:	5	,Bush:	515096	, Gore:	203053	))
        states.append(State(Name: "Vermont", ElectoralVotes:	3	,Bush:	119775	, Gore:	149022	))
        states.append(State(Name: "Virginia", ElectoralVotes:	13	,Bush:	1437490	, Gore:	1217290	))
        states.append(State(Name: "Washington", ElectoralVotes:	11	,Bush:	1108864	, Gore:	1247652	))
        states.append(State(Name: "WestVirginia", ElectoralVotes:	5	,Bush:	336473	, Gore:	295497	))
        states.append(State(Name: "Wisconsin", ElectoralVotes:	11	,Bush:	0	, Gore:	0	))
        states.append(State(Name: "Wyoming", ElectoralVotes:	3	,Bush:	147947	, Gore:	60481	))
        
        
        
        statePicker = UIPickerView(frame: CGRect(x: 0, y: 120, width: 450, height: 100))
        statePicker.delegate = self
        self.view.addSubview(statePicker)
        
        
        
        let electoralVotesLabel = UILabel(frame: CGRect(x: 0, y: 220, width: 250, height: 20))
        electoralVotesLabel.text = "Selected State's Electoral Votes:"
        self.view.addSubview(electoralVotesLabel)
        numberOfVotesLabel = UILabel(frame: CGRect(x: 250, y: 220, width: 25, height: 20))
        //numberOfVotesLabel.backgroundColor = UIColor.lightGray
        numberOfVotesLabel.textAlignment = NSTextAlignment.center
        self.view.addSubview(numberOfVotesLabel)
        
        let textLabel1 = UILabel(frame: CGRect(x: 0, y: 270, width: 250, height: 20))
        textLabel1.text = "Democrat Total of Popular Vote:"
        self.view.addSubview(textLabel1)
        popularDemocrateLabel = UILabel(frame: CGRect(x: 280, y: 270, width: 100, height: 20))
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        popularDemocrateLabel.text = numberFormatter.string(from: NSNumber(value: popularDemocratVoteTotal))
        self.view.addSubview(popularDemocrateLabel)
        
        let textLabel2 = UILabel(frame: CGRect(x: 0, y: 290, width: 270, height: 20))
        textLabel2.text = "Republican Total of Popular Vote:"
        self.view.addSubview(textLabel2)
        popularRepublicanLabel = UILabel(frame: CGRect(x: 280, y: 290, width: 100, height: 20))
        popularRepublicanLabel.text = numberFormatter.string(from: NSNumber(value: popularRepublicanVoteTotal))
        self.view.addSubview(popularRepublicanLabel)
        

        democratTotal = UILabel(frame: CGRect(x: 0, y: 330, width: 310, height: 20))
        democratTotal.text = "Democrat Total of Electoral Votes:   \(totalDemocrat)"
        self.view.addSubview(democratTotal)
        republicanTotal = UILabel(frame: CGRect(x: 0, y: 350, width: 310, height: 20))
        republicanTotal.text = "Republican Total of Electoral Votes: \(totalRepublican)"
        self.view.addSubview(republicanTotal)
        
        
        
        
        textField1 = UITextField(frame: CGRect(x: 180, y: 25, width: 150, height: 35))
        textField1.backgroundColor = UIColor.lightGray
        textField1.font = UIFont(name: "Times", size: 30.0)
        textField1.keyboardType = .numberPad
        self.view.addSubview(textField1)
        textField2 = UITextField(frame: CGRect(x: 180, y: 65, width: 150, height: 35))
        textField2.backgroundColor = UIColor.lightGray
        textField2.font = UIFont(name: "Times", size: 30.0)
        textField2.keyboardType = .numberPad
        self.view.addSubview(textField2)
        
        let myLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 400, height: 20))
        myLabel.text = "Enter the Missing Vote Totals Below and Hit Update"
        myLabel.textAlignment = .center
        view.addSubview(myLabel)
        
        let textLabel3 = UILabel(frame: CGRect(x: 0, y: 25, width: 150, height: 35))
        textLabel3.text = "Democrats:"
        textLabel3.font = UIFont(name: "Times", size: 30.0)
        self.view.addSubview(textLabel3)
        let textLabel4 = UILabel(frame: CGRect(x: 0, y: 65, width: 180, height: 35))
        textLabel4.text = "Republicans:"
        textLabel4.font = UIFont(name: "Times", size: 30.0)
        self.view.addSubview(textLabel4)
        myButton = UIButton(frame: CGRect(x: 320, y: 45, width: 100, height: 30))
        myButton.setTitleColor(UIColor.blue, for: UIControlState())
        myButton.setTitle("Update", for: UIControlState())
        myButton.addTarget(self, action: #selector(onCheckButtonPressed(_:)), for: .touchUpInside)
        self.view.addSubview(myButton)
        
        numberOfVotesLabel.text = "3"
        
        createStates()
    }
    
    func onCheckButtonPressed(_ sender: UIButton)
    {
        
        textField1.resignFirstResponder()
        textField2.resignFirstResponder()
        electoralVotes = Int(numberOfVotesLabel.text!)!
        numberOfDemocratVotes = Int(textField1.text!)!
        numberOfRepublicanVotes = Int(textField2.text!)!
        currentState = states[selectedRow].name
        
        states[selectedRow].bush_chaney_votes = numberOfRepublicanVotes
        states[selectedRow].gore_liberman_votes = numberOfDemocratVotes
        
        

        popularDemocratVoteTotal += numberOfDemocratVotes
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        popularDemocrateLabel.text = numberFormatter.string(from: NSNumber(value: popularDemocratVoteTotal))

        popularRepublicanVoteTotal += numberOfRepublicanVotes
        popularRepublicanLabel.text = numberFormatter.string(from: NSNumber(value: popularRepublicanVoteTotal))
        
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, numberOfRepublicanVotes)
//#-code-completion(identifier, show, numberOfDemocratVotes)
//#-code-completion(identifier, show, electoralVotes)
//#-end-hidden-code
//: If the **numberOfDemocratVotes** is greater than the **numberOfRepublicanVotes**, then the democrats get all of the electoral votes. If the **numberOfRepublicanVotes** is greater than the **numberOfDemocratVotes**, then the republicans get all of the electoral votes.
if <#Variable#> > <#Variable#>
{
    democratsGetAllOfThe(<#Variable#>)
}
else
{
    republicansGetAllOfThe(<#Variable#>)
}
        //#-hidden-code
        
//        if numberOfDemocratVotes > numberOfRepublicanVotes
//        {
//            democratsGetAllOfThe(electoralVotes)
//        }
//        else
//        {
//            republicansGetAllOfThe(electoralVotes)
//        }
        
    }
    
    func colorThe(state: String, c: UIColor)
    {
        if let node = scene?.childNode(withName: state) as? SKSpriteNode
        {
            node.color = c
        }
    }
    
    func republicansGetAllOfThe(_ v:Int)
    {
        totalRepublican += v
        republicanTotal.text = "Republican Total of Electoral Votes: \(totalRepublican)"
        colorThe(state: currentState,c: UIColor.red)
    }
    
    func democratsGetAllOfThe(_ v:Int)
    {
        totalDemocrat += v
        democratTotal.text = "Democrat Total of Electoral Votes:   \(totalDemocrat)"
        colorThe(state: currentState,c: UIColor.blue)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return states.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return states[row].name
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textField1.text = String(describing: states[row].gore_liberman_votes)
        textField2.text = String(describing: states[row].bush_chaney_votes)
        numberOfVotesLabel.text = String(states[row].electoralVotes)
        selectedRow = row
        //onCheckButtonPressed(myButton)
    }
    
    func createStates()
    {
        mapView = SKView(frame: CGRect(x: 0, y: 375, width: 450, height: 320))
        mapView.backgroundColor = UIColor.blue
        view.addSubview(mapView)
        mapView.presentScene(scene)
    }
    
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
