//: If the **subject** is yo, place aprendo in **correctConjugation**. If the **subject** is tu, place aprendes in **correctConjugation**. If the **subject** is el,ella,usted, place aprende in **correctConjugation**. If the **subject** is nosotros, place aprendemos in  **correctConjugation**. If none of the above statements was found, place aprenden in  **correctConjugation**.
//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate
{
    
    
    var myLabel: UILabel!
    var myPicker: UIPickerView!
    var imageView: UIImageView!
    var subjectList = ["yo","tu","el,ella,usted","nosotros","ellos,ellas,ustedes"]
    var subject = String()
    var correctConjugation = String()
    var textToDisplay = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.frame = CGRect(x: 0, y: 0, width: 400, height: 720)
        self.view.backgroundColor = UIColor.white
        createUIElements()
        subject = subjectList[0]
        runMVP()
    }
    
    func createUIElements() {
        
        myLabel = UILabel(frame: CGRect(x: 90, y: 380, width: 228, height: 60))
        myLabel.textAlignment = NSTextAlignment.center
        myLabel.backgroundColor = UIColor.lightGray
        myLabel.textColor = UIColor.black
        myLabel.font = UIFont(name: "Times", size: 40.0)
        myPicker = UIPickerView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 216))
        myPicker.delegate = self
        
        imageView = UIImageView(frame: CGRect(x: 90, y: 440, width: 228, height: 200))
        
        self.view.addSubview(myLabel)
        self.view.addSubview(myPicker)
        self.view.addSubview(imageView)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return subjectList.count
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return subjectList[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        subject = subjectList[row]
        runMVP()
    }
    
    
    func runMVP()
    {
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, subject, correctConjugation)
//#-editable-code
if <#Variable#> == "<#String#>"
{
    <#Variable#> = "<#String#>"
}
else if <#Variable#> == "<#String#>"
{
    <#Variable#> = "<#String#>"
}
else if <#Variable#> == "<#String#>"
{
    <#Variable#> = "<#String#>"
}
else if <#Variable#> == "<#String#>"
{
    <#Variable#> = "<#String#>"
}
else
{
    <#Variable#> = "<#String#>"
}
        
        //#-hidden-code
        //#-end-editable-code
        if subject == "yo"
        {
            //            correctConjugation = "aprendo"
            imageView.image = UIImage(named: "Yo")
        }
        else if subject == "tu"
        {
            //            correctConjugation = "aprendes"
            imageView.image = UIImage(named: "Tu")
        }
        else if subject == "el,ella,usted"
        {
            //            correctConjugation = "aprende"
            imageView.image = UIImage(named: "El")
        }
        else if subject == "nosotros"
        {
            //            correctConjugation = "aprendemos"
            imageView.image = UIImage(named: "Nosotros")
        }
        else
        {
            //            correctConjugation = "aprenden"
            imageView.image = UIImage(named: "Ellos")
        }
        
        
        
        myLabel.text = correctConjugation
        
        
    }
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
