//#-hidden-code

import UIKit
import PlaygroundSupport

class ViewController: UIViewController, UITextFieldDelegate
{
    //TextField Delegate Functions
    @IBOutlet var inputTop1TextField: UITextField! = UITextField(frame: CGRect(x: 110, y: 15, width: 25, height: 25))
    
    @IBOutlet var inputTop2TextField: UITextField! = UITextField(frame: CGRect(x: 260, y: 15, width: 25, height: 25))
    
    @IBOutlet var inputSide1TextField: UITextField! = UITextField(frame: CGRect(x: 10, y: 80, width: 25, height: 25))
    
    @IBOutlet var inputSide2TextField: UITextField! = UITextField(frame: CGRect(x: 10, y: 170, width: 25, height: 25))
    
    var phenotypeTop1Label = UILabel(frame: CGRect(x: 110, y: 245, width: 25, height: 25))
    var phenotypeTop2Label = UILabel(frame: CGRect(x: 260, y: 245, width: 25, height: 25))
    var phenotypeSide1Label = UILabel(frame: CGRect(x: 10, y: 310, width: 25, height: 25))
    var phenotypeSide2Label = UILabel(frame: CGRect(x: 10, y: 395, width: 25, height: 25))
    
    
    var genotypeLabel = [[UILabel]]()
    var phenotypeImageView = [[UIImageView]]()
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true;
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder();
        return true
    }
    
    func textField(_ textField: UITextField,shouldChangeCharactersIn range: NSRange,replacementString string: String) -> Bool
    {
        guard let text = textField.text else { return true }
        let limitLength = 1
        
        let newLength = text.characters.count + string.characters.count - range.length
        if newLength > limitLength {
            return false
        }
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let myView = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 600))
        view.backgroundColor = UIColor.gray
        
        //Create background image view and draw static background of two four by four grids.
        
        let punnettWidth: Int = 300
        let punnettHeight: Int = 350
        let myLineWidth: Int = 4
        
        let myPunnettSquares = UIImageView(frame: CGRect(x: 50, y: 50, width: punnettWidth, height: punnettHeight+60))
        
        UIGraphicsBeginImageContextWithOptions(CGSize(width: punnettWidth, height: punnettHeight+60), false, 1.0)
        let context = UIGraphicsGetCurrentContext()
        
        context?.setStrokeColor(UIColor.black.cgColor)
        context?.setLineWidth(CGFloat(myLineWidth))
        context?.beginPath()
        context?.addRect(CGRect(x: myLineWidth/2, y: myLineWidth/2, width: punnettWidth/2-myLineWidth/2, height: punnettHeight/4-myLineWidth/2))
        context?.addRect(CGRect(x: punnettWidth/2, y: myLineWidth/2,  width: punnettWidth/2-myLineWidth/2, height: punnettHeight/4-myLineWidth/2))
        context?.addRect(CGRect(x: myLineWidth/2, y: myLineWidth/2, width: punnettWidth/2-myLineWidth/2, height: punnettHeight/2-myLineWidth/2))
        context?.addRect(CGRect(x: punnettWidth/2, y: myLineWidth/2,  width: punnettWidth/2-myLineWidth/2, height: punnettHeight/2-myLineWidth/2))
        context?.addRect(CGRect(x: myLineWidth/2, y: punnettHeight/2+55, width: punnettWidth/2-myLineWidth/2, height: punnettHeight/4-myLineWidth/2))
        context?.addRect(CGRect(x: punnettWidth/2, y: punnettHeight/2+55,  width: punnettWidth/2-myLineWidth/2, height: punnettHeight/4-myLineWidth/2))
        context?.addRect(CGRect(x: myLineWidth/2, y: punnettHeight/2+55, width: punnettWidth/2-myLineWidth/2, height: punnettHeight/2-myLineWidth/2))
        context?.addRect(CGRect(x: punnettWidth/2, y: punnettHeight/2+55,  width: punnettWidth/2-myLineWidth/2, height: punnettHeight/2-myLineWidth/2))
        context?.strokePath()
        
        context?.setLineWidth(CGFloat(myLineWidth/2))
        context?.move(to: CGPoint(x: 0, y: punnettHeight/2+10))
        context?.addLine(to:CGPoint(x: punnettWidth+10, y: punnettHeight/2+10))
        context?.strokePath()
        
        myPunnettSquares.image = UIGraphicsGetImageFromCurrentImageContext()!
        
        
        //Add Buttons
        
        let myButton = UIButton(frame: CGRect(x: 120, y: 480, width: 180, height: 25))
        myButton.backgroundColor = UIColor.lightGray
        myButton.setTitle("Show me the babies!", for: [])
        myButton.addTarget(self, action: #selector(myButtonAction), for: .touchUpInside)
        
        //Dealing with TextFields
        
        inputTop1TextField.delegate = self
        inputTop1TextField.backgroundColor = UIColor.white
        inputTop1TextField.autocapitalizationType = UITextAutocapitalizationType.none
        inputTop1TextField.textAlignment = NSTextAlignment.center
        
        inputTop2TextField.delegate = self
        inputTop2TextField.backgroundColor = UIColor.white
        inputTop2TextField.autocapitalizationType = UITextAutocapitalizationType.none
        inputTop2TextField.textAlignment = NSTextAlignment.center
        
        inputSide1TextField.delegate = self
        inputSide1TextField.backgroundColor = UIColor.white
        inputSide1TextField.autocapitalizationType = UITextAutocapitalizationType.none
        inputSide1TextField.textAlignment = NSTextAlignment.center
        
        inputSide2TextField.delegate = self
        inputSide2TextField.backgroundColor = UIColor.white
        inputSide2TextField.autocapitalizationType = UITextAutocapitalizationType.none
        inputSide2TextField.textAlignment = NSTextAlignment.center
        
        //Labels
        
        for x in 0...1{
            var tempArray = [UILabel]()
            for y in 0...1{
                let tempLabel = UILabel(frame: CGRect(x: 100+150*x, y: 80+90*y, width: 50, height: 25))
                tempLabel.backgroundColor = UIColor.lightGray
                tempLabel.textAlignment = NSTextAlignment.center
                tempArray.append(tempLabel)
            }
            genotypeLabel.append(tempArray)
        }
        
        for x in 0...1{
            var tempArray = [UIImageView]()
            for y in 0...1{
                let tempImageView = UIImageView(frame: CGRect(x: 90+150*x, y: 285+85*y, width: 75, height: 75))
                tempImageView.backgroundColor = UIColor.lightGray
                tempArray.append(tempImageView)
            }
            phenotypeImageView.append(tempArray)
        }
        
        phenotypeTop1Label.backgroundColor = UIColor.lightGray
        phenotypeTop2Label.backgroundColor = UIColor.lightGray
        phenotypeSide1Label.backgroundColor = UIColor.lightGray
        phenotypeSide2Label.backgroundColor = UIColor.lightGray
        
        phenotypeTop1Label.textAlignment = NSTextAlignment.center
        phenotypeTop2Label.textAlignment = NSTextAlignment.center
        phenotypeSide1Label.textAlignment = NSTextAlignment.center
        phenotypeSide2Label.textAlignment = NSTextAlignment.center
        
        let genotypeSectionLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 160, height: 50))
        genotypeSectionLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        genotypeSectionLabel.numberOfLines = 0
        genotypeSectionLabel.text = "Genotype\nSquare"
        
        let phenotypeSectionLabel = UILabel(frame: CGRect(x: 2, y: 230, width: 160, height: 50))
        phenotypeSectionLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        phenotypeSectionLabel.numberOfLines = 0
        phenotypeSectionLabel.text = "Phenotype\nSquare"
        
        //Add Subviews
        self.view.addSubview(myView)
        
        self.view.addSubview(myPunnettSquares)
        
        self.view.addSubview(myButton)
        
        self.view.addSubview(inputTop1TextField)
        self.view.addSubview(inputTop2TextField)
        self.view.addSubview(inputSide1TextField)
        self.view.addSubview(inputSide2TextField)
        self.view.addSubview(phenotypeTop1Label)
        self.view.addSubview(phenotypeTop2Label)
        self.view.addSubview(phenotypeSide1Label)
        self.view.addSubview(phenotypeSide2Label)
        for x in 0...1{
            for y in 0...1{
                self.view.addSubview(genotypeLabel[x][y])
                self.view.addSubview(phenotypeImageView[x][y])
            }
        }
        self.view.addSubview(genotypeSectionLabel)
        self.view.addSubview(phenotypeSectionLabel)
        
    }
    
    func myButtonAction(sender: UIButton) {
        genotypeLabel[0][0].text = inputTop1TextField.text! + inputSide1TextField.text!
        genotypeLabel[0][0].text = String(Array(genotypeLabel[0][0].text!.characters).sorted())
        
        setPhenotypeFromGenotype(genotype: genotypeLabel[0][0].text!, phenotypeIV: phenotypeImageView[0][0])
        
        genotypeLabel[1][0].text = inputTop2TextField.text! + inputSide1TextField.text!
        genotypeLabel[1][0].text = String(Array(genotypeLabel[1][0].text!.characters).sorted())
        
        setPhenotypeFromGenotype(genotype: genotypeLabel[1][0].text!, phenotypeIV: phenotypeImageView[1][0])
        
        genotypeLabel[0][1].text = inputTop1TextField.text! + inputSide2TextField.text!
        genotypeLabel[0][1].text = String(Array(genotypeLabel[0][1].text!.characters).sorted())
        setPhenotypeFromGenotype(genotype: genotypeLabel[0][1].text!, phenotypeIV: phenotypeImageView[0][1])
        
        genotypeLabel[1][1].text = inputTop2TextField.text! + inputSide2TextField.text!
        genotypeLabel[1][1].text = String(Array(genotypeLabel[1][1].text!.characters).sorted())
        setPhenotypeFromGenotype(genotype: genotypeLabel[1][1].text!, phenotypeIV: phenotypeImageView[1][1])
        
        phenotypeTop1Label.text = inputTop1TextField.text
        phenotypeTop2Label.text = inputTop2TextField.text
        phenotypeSide1Label.text = inputSide1TextField.text
        phenotypeSide2Label.text = inputSide2TextField.text
    }
    
    func setPhenotypeFromGenotype(genotype: String, phenotypeIV: UIImageView){
        var phenotype = ""
        
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, genotype, phenotype)
//: If the **genotype** is equal to "YY", then **phenotype** should equal "yellow". If the **genotype** is equal to "Yy", then **phenotype** should equal "yellow". If the **genotype** is equal to "yy", then **phenotype** should equal "green".
        
        if <#Variable#> == "<#String#>" {
            <#Variable#> = "<#String#>"
        }
        
        if <#Variable#> == "<#String#>" {
            <#Variable#> = "<#String#>"
        }
        
        if <#Variable#> == "<#String#>" {
            <#Variable#> = "<#String#>"
        }
//#-hidden-code
        
        if phenotype == "green" {
            phenotypeIV.backgroundColor = UIColor.green
            phenotypeIV.image = UIImage(named: "MendelPeaGreen.png")
        }
        if phenotype == "yellow" {
            phenotypeIV.backgroundColor = UIColor.yellow
            phenotypeIV.image = UIImage(named: "MendelPeaYellow.png")
        }
    }
    
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
