//: If the **nucleotideInDNAFragment** is equal to A, then the **replicatedNucleotide** should be T. If the **nucleotideInDNAFragment** is equal to T, then the **replicatedNucleotide** should be A. If the **nucleotideInDNAFragment** is equal to C, then the **replicatedNucleotide** should be G. If the **nucleotideInDNAFragment** is equal to G, then the **replicatedNucleotide** should be C.
//:
//#-hidden-code
import UIKit
import PlaygroundSupport

let DNAFragment: String = "CTGACG"
var ReplicatedDNAStrand: String = "??????"

class ViewController: UIViewController
{
    let DNAFragmentLabelLetter1 = UILabel(frame: CGRect(x: 66, y: 4, width: 40, height: 40))
    let DNAFragmentLabelLetter2 = UILabel(frame: CGRect(x: 66, y: 56, width: 40, height: 40))
    let DNAFragmentLabelLetter3 = UILabel(frame: CGRect(x: 66, y: 108, width: 40, height: 40))
    let DNAFragmentLabelLetter4 = UILabel(frame: CGRect(x: 66, y: 160, width: 40, height: 40))
    let DNAFragmentLabelLetter5 = UILabel(frame: CGRect(x: 66, y: 211, width: 40, height: 40))
    let DNAFragmentLabelLetter6 = UILabel(frame: CGRect(x: 66, y: 262, width: 40, height: 40))
    
    let ReplicatedDNALabelLetter1 = UILabel(frame: CGRect(x: 124, y: 4, width: 40, height: 40))
    let ReplicatedDNALabelLetter2 = UILabel(frame: CGRect(x: 124, y: 56, width: 40, height: 40))
    let ReplicatedDNALabelLetter3 = UILabel(frame: CGRect(x: 124, y: 108, width: 40, height: 40))
    let ReplicatedDNALabelLetter4 = UILabel(frame: CGRect(x: 124, y: 160, width: 40, height: 40))
    let ReplicatedDNALabelLetter5 = UILabel(frame: CGRect(x: 124, y: 211, width: 40, height: 40))
    let ReplicatedDNALabelLetter6 = UILabel(frame: CGRect(x: 124, y: 262, width: 40, height: 40))
    
    let BackgroundImage = UIImageView(image: #imageLiteral(resourceName: "DNA-Coding-Background-Image.png"))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let myView = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 600))
        view.backgroundColor = UIColor.black
        
        let replicateButton = UIButton(frame: CGRect(x: 125, y: 325, width: 150, height: 25))
        
        replicateButton.backgroundColor = UIColor.gray
        replicateButton.setTitle("Replicate!", for: [])
        
        replicateButton.addTarget(self, action: #selector(replicateButtonAction), for: .touchUpInside)
        
        DNAFragmentLabelLetter1.textAlignment = NSTextAlignment(rawValue: 1)!
        DNAFragmentLabelLetter1.text = String(DNAFragment[DNAFragment.startIndex])
        DNAFragmentLabelLetter1.text = String(DNAFragment[DNAFragment.index(DNAFragment.startIndex, offsetBy:0)])
        
        DNAFragmentLabelLetter2.textAlignment = NSTextAlignment(rawValue: 1)!
        DNAFragmentLabelLetter2.text = String(DNAFragment[DNAFragment.startIndex])
        DNAFragmentLabelLetter2.text = String(DNAFragment[DNAFragment.index(DNAFragment.startIndex, offsetBy:1)])
        
        DNAFragmentLabelLetter3.textAlignment = NSTextAlignment(rawValue: 1)!
        DNAFragmentLabelLetter3.text = String(DNAFragment[DNAFragment.startIndex])
        DNAFragmentLabelLetter3.text = String(DNAFragment[DNAFragment.index(DNAFragment.startIndex, offsetBy:2)])
        
        DNAFragmentLabelLetter4.textAlignment = NSTextAlignment(rawValue: 1)!
        DNAFragmentLabelLetter4.text = String(DNAFragment[DNAFragment.startIndex])
        DNAFragmentLabelLetter4.text = String(DNAFragment[DNAFragment.index(DNAFragment.startIndex, offsetBy:3)])
        
        DNAFragmentLabelLetter5.textAlignment = NSTextAlignment(rawValue: 1)!
        DNAFragmentLabelLetter5.text = String(DNAFragment[DNAFragment.startIndex])
        DNAFragmentLabelLetter5.text = String(DNAFragment[DNAFragment.index(DNAFragment.startIndex, offsetBy:4)])
        
        DNAFragmentLabelLetter6.textAlignment = NSTextAlignment(rawValue: 1)!
        DNAFragmentLabelLetter6.text = String(DNAFragment[DNAFragment.startIndex])
        DNAFragmentLabelLetter6.text = String(DNAFragment[DNAFragment.index(DNAFragment.startIndex, offsetBy:5)])
        
        ReplicatedDNALabelLetter1.textAlignment = NSTextAlignment(rawValue: 1)!
        ReplicatedDNALabelLetter1.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.startIndex])
        ReplicatedDNALabelLetter1.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.index(ReplicatedDNAStrand.startIndex, offsetBy:1)])
        
        ReplicatedDNALabelLetter2.textAlignment = NSTextAlignment(rawValue: 1)!
        ReplicatedDNALabelLetter2.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.startIndex])
        ReplicatedDNALabelLetter2.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.index(ReplicatedDNAStrand.startIndex, offsetBy:1)])
        
        ReplicatedDNALabelLetter3.textAlignment = NSTextAlignment(rawValue: 1)!
        ReplicatedDNALabelLetter3.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.startIndex])
        ReplicatedDNALabelLetter3.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.index(ReplicatedDNAStrand.startIndex, offsetBy:1)])
        
        ReplicatedDNALabelLetter4.textAlignment = NSTextAlignment(rawValue: 1)!
        ReplicatedDNALabelLetter4.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.startIndex])
        ReplicatedDNALabelLetter4.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.index(ReplicatedDNAStrand.startIndex, offsetBy:1)])
        
        ReplicatedDNALabelLetter5.textAlignment = NSTextAlignment(rawValue: 1)!
        ReplicatedDNALabelLetter5.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.startIndex])
        ReplicatedDNALabelLetter5.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.index(ReplicatedDNAStrand.startIndex, offsetBy:1)])
        
        ReplicatedDNALabelLetter6.textAlignment = NSTextAlignment(rawValue: 1)!
        ReplicatedDNALabelLetter6.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.startIndex])
        ReplicatedDNALabelLetter6.text = String(ReplicatedDNAStrand[ReplicatedDNAStrand.index(ReplicatedDNAStrand.startIndex, offsetBy:1)])
        
        DNAFragmentLabelLetter1.backgroundColor = UIColor.lightGray
        DNAFragmentLabelLetter2.backgroundColor = UIColor.lightGray
        DNAFragmentLabelLetter3.backgroundColor = UIColor.lightGray
        DNAFragmentLabelLetter4.backgroundColor = UIColor.lightGray
        DNAFragmentLabelLetter5.backgroundColor = UIColor.lightGray
        DNAFragmentLabelLetter6.backgroundColor = UIColor.lightGray
        
        ReplicatedDNALabelLetter1.backgroundColor = UIColor.lightGray
        ReplicatedDNALabelLetter2.backgroundColor = UIColor.lightGray
        ReplicatedDNALabelLetter3.backgroundColor = UIColor.lightGray
        ReplicatedDNALabelLetter4.backgroundColor = UIColor.lightGray
        ReplicatedDNALabelLetter5.backgroundColor = UIColor.lightGray
        ReplicatedDNALabelLetter6.backgroundColor = UIColor.lightGray
        
        self.view.addSubview(myView)
        self.view.addSubview(BackgroundImage)
        self.view.addSubview(replicateButton)
        self.view.addSubview(DNAFragmentLabelLetter1)
        self.view.addSubview(DNAFragmentLabelLetter2)
        self.view.addSubview(DNAFragmentLabelLetter3)
        self.view.addSubview(DNAFragmentLabelLetter4)
        self.view.addSubview(DNAFragmentLabelLetter5)
        self.view.addSubview(DNAFragmentLabelLetter6)
        self.view.addSubview(ReplicatedDNALabelLetter1)
        self.view.addSubview(ReplicatedDNALabelLetter2)
        self.view.addSubview(ReplicatedDNALabelLetter3)
        self.view.addSubview(ReplicatedDNALabelLetter4)
        self.view.addSubview(ReplicatedDNALabelLetter5)
        self.view.addSubview(ReplicatedDNALabelLetter6)
    }
    
    func replicateButtonAction(sender: UIButton) {
        
        let basePair1: [UILabel] = [DNAFragmentLabelLetter1, ReplicatedDNALabelLetter1]
        let basePair2: [UILabel] = [DNAFragmentLabelLetter2,ReplicatedDNALabelLetter2]
        let basePair3: [UILabel] = [DNAFragmentLabelLetter3,ReplicatedDNALabelLetter3]
        let basePair4: [UILabel] = [DNAFragmentLabelLetter4,ReplicatedDNALabelLetter4]
        let basePair5: [UILabel] = [DNAFragmentLabelLetter5,ReplicatedDNALabelLetter5]
        let basePair6: [UILabel] = [DNAFragmentLabelLetter6,ReplicatedDNALabelLetter6]
        
        let DNAArray = [basePair1,basePair2,basePair3,basePair4,basePair5,basePair6]
        
        var nucleotideInDNAFragment: String = ""
        var replicatedNucleotide: String = ""
        
        for basePair in (DNAArray) {
            
            nucleotideInDNAFragment = basePair[0].text!
            //#-code-completion(everything, hide)
            //#-code-completion(identifier, show, nucleotideInDNAFragment, replicatedNucleotide)
            //#-end-hidden-code
            //#-editable-code
            
if <#Variable#> == "<#Letter#>"
{
    <#Variable#>  = "<#Letter#>"
}
if <#Variable#>  == "<#Letter#>"
{
    <#Variable#>  = "<#Letter#>"
}
if <#Variable#>  == "<#Letter#>"
{
    <#Variable#>  = "<#Letter#>"
}
if <#Variable#>  == "<#Letter#>"
{
    <#Variable#>  = "<#Letter#>"
}
            //#-end-editable-code
            //#-hidden-code
            
//            if nucleotideInDNAFragment == "A"
//            {
//                replicatedNucleotide = "T"
//            }
//            
//            if nucleotideInDNAFragment == "T"
//            {
//                replicatedNucleotide = "A"
//            }
//            
//            if nucleotideInDNAFragment == "C"
//            {
//                replicatedNucleotide = "A"
//            }
//            
//            if nucleotideInDNAFragment == "G"
//            {
//                replicatedNucleotide = "A"
//            }
            
            basePair[1].text! = replicatedNucleotide
        }
    }
    
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
