//#-hidden-code
_setup()


func f(_ x: Double) -> Double {

//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, x)
//: If **x** is less than -2, return 4. Else if **x** is greater than or equal to -2 and **x** is less then 1, then return **x** * **x**. Else, return **-x** plus 2.
if <#Variable#> < 0
{
    return 0
}
else if <#Variable#> >= 0 && <#Variable#> < 0
{
    return <#Variable#> * <#Variable#>
}
else
{
    return -<#Variable#> + 0
}
//#-hidden-code
//    if x < -2
//    {
//        return 4
//    }
//    else if x >= -2 && x < 1
//    {
//        return x*x
//    }
//    else
//    {
//        return -x + 2
//    }
}
let function2 = LinePlot(function: f)
//#-end-hidden-code
