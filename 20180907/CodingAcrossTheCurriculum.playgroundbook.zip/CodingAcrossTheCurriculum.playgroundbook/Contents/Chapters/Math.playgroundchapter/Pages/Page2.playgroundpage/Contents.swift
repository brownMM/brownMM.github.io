//: Fill in the scoring so that if your guess is equal to the calculated value, then your score increases by one, and otherwise, your score decreases by one.

//#-hidden-code
import UIKit
import PlaygroundSupport

//Declarations
var scaleFactor = Double(20)
var pointRadius = Double(10)
var myScore = 0
var pictureOfGraph = UIImage()
var newPoint = [Double(0),Double(0)]
var myPointsToGraph = [newPoint]
myPointsToGraph.removeFirst()

let myGraph = UIImageView(frame: CGRect(x: 5, y: 5, width: 360, height: 360))


class ViewController: UIViewController, UITextFieldDelegate
{
    
    @IBOutlet var inputText: UITextField! = UITextField(frame: CGRect(x: 140, y: 300, width: 50, height: 23))
    
    @IBOutlet var guessText: UITextField! = UITextField(frame: CGRect(x: 140, y: 325, width: 50, height: 23))
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true;
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder();
        
        if Double(textField.text!) != nil{
            return true
        }else{
            textField.text = ""
            return false
        }
    }
    
    func textField(_ textField: UITextField,shouldChangeCharactersIn range: NSRange,replacementString string: String) -> Bool
    {
        return true
    }
    
    //Add Labels
    
    let inInputLabel = UILabel(frame: CGRect(x:115, y:300, width: 50, height: 25))
    
    let guessInputLabel = UILabel(frame: CGRect(x:25, y:325, width: 150, height: 25))
    
    let inOutTableLabel = UILabel(frame: CGRect(x:275, y:250, width: 150, height: 250))
    
    let scoreLabel = UILabel(frame: CGRect(x: 49, y: 360, width: 150, height: 25))
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let myView = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 600))
        view.backgroundColor = UIColor.lightGray
        
        //Add Buttons
        
        let getOutputButton = UIButton(frame: CGRect(x: 100, y: 400, width: 160, height: 25))
        getOutputButton.backgroundColor = UIColor.gray
        getOutputButton.setTitle("Get Output!", for: [])
        getOutputButton.addTarget(self, action: #selector(GetOutputAction), for: .touchUpInside)
        
        let resetButton = UIButton(frame: CGRect(x: 150, y: 440, width: 50, height: 25))
        resetButton.backgroundColor = UIColor.gray
        resetButton.setTitle("Reset", for: [])
        resetButton.addTarget(self, action: #selector(myButtonAction), for: .touchUpInside)
        
        //Dealing with TextFields
        guessText.delegate = self
        inputText.delegate = self
        
        guessText.backgroundColor = UIColor.white
        inputText.backgroundColor = UIColor.white
        
        //Set initial values for labels
        inInputLabel.text = "In:"
        guessInputLabel.text = "Predicted Out:"
        inOutTableLabel.numberOfLines = 0
        inOutTableLabel.text = "  In  |  Out  \n" + "========"
        scoreLabel.text = "Your Score: 0"
        
        //Add Subviews
        self.view.addSubview(myView)
        self.view.addSubview(myGraph)
        self.view.addSubview(getOutputButton)
        self.view.addSubview(resetButton)
        self.view.addSubview(guessInputLabel)
        self.view.addSubview(inInputLabel)
        self.view.addSubview(inOutTableLabel)
        self.view.addSubview(scoreLabel)
        self.view.addSubview(inputText)
        self.view.addSubview(guessText)
        
        DrawTheGraph()
    }
    
    func myButtonAction(sender: UIButton) {
        if sender.backgroundColor == UIColor.blue{
            sender.backgroundColor = UIColor.gray}
        else{
            sender.backgroundColor = UIColor.blue}
    }
    
    func GetOutputAction(sender: UIButton) {
        // Take In value, put it through function, get output,
        // Set in/out table
        // Call scoring function.
        CalculateTheNewPoint(x: Double(inputText.text!)!)
        ScoreTheAttempt()
        DrawTheGraph()
    }
    func CalculateTheNewPoint(x: Double){
        let slope = Double(2)
        let yIntercept = Double(-3)
        var y: Double
        y = slope * x + yIntercept
        
        newPoint = [x,y]
        myPointsToGraph.append(newPoint)
        
        inOutTableLabel.text! += "\n"
        inOutTableLabel.text! += "  ("
        inOutTableLabel.text! += (String(x) + ",")
        inOutTableLabel.text! += ("  " + String(y)+")")
    }
    
    func ScoreTheAttempt(){
        
        let myGuess = Double(guessText.text!)
        let calculatedValue = newPoint[1]
        
        //#-end-hidden-code
        //#-editable-code
        
        if myGuess == calculatedValue{
            myScore = myScore + 1
        }else{
            myScore = myScore - 1
        }
        //#-hidden-code
        //#-end-editable-code
        
        scoreLabel.text = "Your Score: " + String(myScore)
    }
    
    func DrawTheGraph(){
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 350, height: 350), false, 1.0)
        let context = UIGraphicsGetCurrentContext()
        
        context?.setStrokeColor(UIColor.gray.cgColor)
        context?.setLineWidth(1)
        context?.beginPath()
        //Horizontal Grid Lines
        for xValue in 0...17 {
            for yValue in 0...14 {
                context?.move(to: CGPoint(x: 0, y: Double(yValue)*scaleFactor))
                context?.addLine(to: CGPoint(x: Double(xValue)*scaleFactor, y: Double(yValue)*scaleFactor))
            }
        }
        
        //Vertical Grid Lines
        for yValue in 0...14 {
            for xValue in 0...17 {
                context?.move(to: CGPoint(x: Double(xValue)*scaleFactor, y: 0))
                context?.addLine(to: CGPoint(x: Double(xValue)*scaleFactor, y: Double(yValue)*scaleFactor))
            }
        }
        context?.strokePath()
        
        context?.setLineWidth(4)
        context?.beginPath()
        context?.move(to: CGPoint(x: 180, y: 0))
        context?.addLine(to: CGPoint(x: 180, y: 280))
        context?.move(to: CGPoint(x: 0, y: 140))
        context?.addLine(to: CGPoint(x:360, y: 140))
        context?.strokePath()
        
        //Draw in Points if there are any
        for somePoint in myPointsToGraph {
            context?.beginPath()
            context?.addEllipse(
                in: CGRect(origin: CGPoint(x: somePoint[0]*scaleFactor+180-pointRadius/2,
                                           y: -somePoint[1]*scaleFactor+130+pointRadius/2),
                           size: CGSize(width: pointRadius, height: pointRadius)
                )
            )
            context?.fillPath()
        }
        
        pictureOfGraph = UIGraphicsGetImageFromCurrentImageContext()!
        
        myGraph.image = pictureOfGraph
    }
}



PlaygroundPage.current.liveView = ViewController()
