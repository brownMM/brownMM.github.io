//#-hidden-code

import UIKit
import PlaygroundSupport


class ViewController: UIViewController, UITextFieldDelegate {
    
    var enteredStock = UITextField(frame: CGRect(x: 160, y: 80, width: 150, height: 40))
    var currentStock = NSDictionary()
    var nameLabel:UILabel!
    var peRatioLabel = UILabel(frame: CGRect(x: 200, y: 250, width: 150, height: 50))
    var suggestionLabel = UILabel(frame: CGRect(x: 200, y: 300, width: 150, height: 50))
    
    
    var highLabel = UILabel(frame: CGRect(x: 200, y: 450, width: 150, height: 50))
    var lowLabel = UILabel(frame: CGRect(x: 200, y: 500, width: 150, height: 50))
    var changeLabel = UILabel(frame: CGRect(x: 200, y: 550, width: 150, height: 50))
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        
        let descriptionLabel = UILabel(frame: CGRect(x: 60, y: 10, width: 300, height: 60))
        descriptionLabel.numberOfLines = 2
        descriptionLabel.textAlignment = NSTextAlignment.center
        descriptionLabel.text = "Enter the Abbreviation of a Stock Below and Press Return"
        view.addSubview(descriptionLabel)
        
        enteredStock.backgroundColor = UIColor.lightGray
        enteredStock.delegate = self
        enteredStock.textAlignment = NSTextAlignment.center
        enteredStock.font = UIFont(name: "Times", size: 30.0)
        view.addSubview(enteredStock)
        nameLabel = UILabel(frame: CGRect(x: 10, y: 150, width: 400, height: 50))
        //nameLabel.backgroundColor = UIColor.lightGray
        nameLabel.textAlignment = NSTextAlignment.center
        nameLabel.font = UIFont(name: "Times", size: 30.0)
        view.addSubview(nameLabel)
        let peRatioDescriptionLabel = UILabel(frame: CGRect(x: 31, y: 250, width: 200, height: 50))
        peRatioDescriptionLabel.text = "P-E Ratio:"
        peRatioDescriptionLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(peRatioDescriptionLabel)
        //peRatioLabel.backgroundColor = UIColor.lightGray
        peRatioLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(peRatioLabel)
        let suggestionDescriptionLabel = UILabel(frame: CGRect(x: 11, y: 300, width: 200, height: 50))
        suggestionDescriptionLabel.text = "Suggestion:"
        suggestionDescriptionLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(suggestionDescriptionLabel)
        //suggestionLabel.backgroundColor = UIColor.lightGray
        suggestionLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(suggestionLabel)
        let highDescriptionLabel = UILabel(frame: CGRect(x: 10, y: 450, width: 200, height: 50))
        highDescriptionLabel.text = "Day's High:"
        highDescriptionLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(highDescriptionLabel)
        //highLabel.backgroundColor = UIColor.lightGray
        highLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(highLabel)
        let lowDescriptionLabel = UILabel(frame: CGRect(x: 16, y: 500, width: 200, height: 50))
        lowDescriptionLabel.text = "Day's Low:"
        lowDescriptionLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(lowDescriptionLabel)
        lowLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(lowLabel)
        
        let changeDescriptionLabel = UILabel(frame: CGRect(x: 66, y: 550, width: 150, height: 50))
        changeDescriptionLabel.text = "Change:"
        changeDescriptionLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(changeDescriptionLabel)
        //changeLabel.backgroundColor = UIColor.lightGray
        changeLabel.font = UIFont(name: "Times", size: 40.0)
        view.addSubview(changeLabel)
        
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        getJSONData(textField.text!)
        textField.resignFirstResponder()
        return true
    }
    
    
    func getJSONData(_ stock: String)
    {
        let urlString = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.quotes%20where%20symbol%20IN%20(%22\(stock)%22)&format=json&env=http://datatables.org/alltables.env"
        let url = URL(string: urlString)
        let request = URLRequest(url: url!)
        let dataTask = URLSession.shared.dataTask(with: request) { (data, response, error) in
            do{
                let jsonDict = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! NSDictionary
                let quotes:NSDictionary = jsonDict.object(forKey: "query") as! NSDictionary
                let results:NSDictionary = quotes.object(forKey: "results") as! NSDictionary
                self.currentStock = results.object(forKey: "quote") as! NSDictionary
                
                self.nameLabel.text = self.currentStock.object(forKey: "Name") as? String
                self.peRatioLabel.text = self.currentStock.object(forKey: "PERatio") as? String
                let peRatio = self.convertStringToDouble(self.peRatioLabel.text!)
                
                
                self.placeTextInLabels(peRatio)
                
                
                self.suggestionLabel.textColor = self.colorLabel(peRatio)
                
                
                self.highLabel.text = self.currentStock.object(forKey: "DaysHigh") as? String
                self.lowLabel.text = self.currentStock.object(forKey: "DaysLow") as? String
                self.changeLabel.text = self.currentStock.object(forKey: "Change") as? String
                
                
            }
            catch
            {
                print("JSON Error ")
            }
        }
        dataTask.resume()
        viewDidLoad()
    }
    
    
    func convertStringToDouble(_ x: String) -> Double
    {
        return Double(x)!
    }
    
    
    func placeTextInLabels(_ peRatio: Double)
    {
        var suggestion = ""
        peRatioLabel.text = "\(peRatio)"
        //#-code-completion(everything, hide)
        //#-code-completion(identifier, show, peRatio, suggestion)
        //#-end-hidden-code
//: If the **peRatio** is under 16.95, place "Buy" in the variable named **suggestion**. If the **peRatio** is between 16.95 and 25.43, place "Hold" in the variable named **suggestion**. If the **peRatio** is above 25.43, place "Sell" in the variable named **suggestion**.
if <#Variable#> < 0.0
{
    <#Variable#> = "<#String#>"
}
else if <#Variable#> < 0.0
{
    <#Variable#> = "<#String#>"
}
else
{
    <#Variable#> = "<#String#>"
}
        //#-hidden-code
        
        
//        if peRatio < 16.95
//        {
//            suggestion = "Buy"
//        }
//        else if peRatio < 25.34
//        {
//            suggestion = "Hold"
//        }
//        else
//        {
//            suggestion = "Sell"
//        }
        
        
        suggestionLabel.text = suggestion
    }
    
    func colorLabel(_ ratio: Double) -> UIColor
    {
        if ratio < 16.95
        {
            return UIColor.green
        }
        else if ratio < 25.43
        {
            return UIColor.yellow
        }
        else
        {
            return UIColor.red
        }
    }
    
    
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
