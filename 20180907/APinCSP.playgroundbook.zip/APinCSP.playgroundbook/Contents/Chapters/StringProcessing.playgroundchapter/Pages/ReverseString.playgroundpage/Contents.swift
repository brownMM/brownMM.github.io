//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let stringLabel = UILabel(frame: CGRect(x: 20, y: 40, width: 350, height: 40))
    
    let stringTextField = UITextField(frame: CGRect(x: 20, y: 80, width: 350, height: 40))
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 300, height: 100))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        stringLabel.text = "Enter a word or phrase below"
        view.addSubview(stringLabel)
        
        stringTextField.backgroundColor = UIColor.lightGray
        view.addSubview(stringTextField)
        
        totalLabel.numberOfLines = 2
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Reverse the String", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    func whenPressed(_ button: UIButton)
    {
        let phrase = stringTextField.text!
        totalLabel.text = """
        With Reversed, \(phrase) backwards is \(reverseWithReversed(phrase))
        With your code, \(phrase) backwards is \(reverse(phrase))
        """
    }
    
    func reverseWithReversed(_ phrase: String) -> String
    {
        return String( phrase.reversed() )
    }
    
//#-end-hidden-code
//: Enter the code inside the function to take the argument phrase and reverse every letter. You must use a loop and cannot use the .reversed method.
//:
//: ![ReverseMethod](ReverseMethod.png)
    func reverse(_ phrase: String) -> String
    {
        <#code#>
    }
//#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
