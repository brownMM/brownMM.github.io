//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 400, height: 80))
    
    let totalButton = UIButton(frame: CGRect(x: 100, y: 10 , width: 250, height: 25))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        totalLabel.numberOfLines = 2
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Convert It", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        var randomNumber:Double
        if arc4random() % 10 < 5 {
            randomNumber = Double(arc4random())/Double(arc4random()/10000000)
        }
        else {
            randomNumber = Double(arc4random()/1000)/Double(arc4random())
        }
        let answer = ScientificNotation(number: randomNumber)
        
        totalLabel.text = "The number \(randomNumber), converted is\n\(String(format: "%0.3f",answer.0)) x 10^\(answer.1)"
    }
    
    
    //#-end-hidden-code
//: Enter the code inside the function to take the argument number and convert it to scientific notation. You must return a tuple representing the number and the expoenent. The playground will generate a number that might be large (1234.5678) or small (0.0000012345)
    
    func ScientificNotation(number: Double) -> (Double,Int)
    {
        <#Code#>
    }
    //#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


