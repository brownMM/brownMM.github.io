//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let wordLabel = UILabel(frame: CGRect(x: 20, y: 50, width: 50, height: 40))
    let wordTextField = UITextField(frame: CGRect(x: 100, y: 50, width: 100, height: 30))
    
    let numberLabel = UILabel(frame: CGRect(x: 20, y: 100, width: 150, height: 40))
    let numberTextField = UITextField(frame: CGRect(x: 170, y: 100, width: 40, height: 30))
    
    let button = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    let textView = UITextView(frame: CGRect(x: 20, y: 200, width: 400, height: 800))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        wordLabel.text = "Word:"
        wordLabel.textAlignment = .center
        numberLabel.text = "Number of Times:"
        numberLabel.textAlignment = .center
        
        view.addSubview(wordLabel)
        view.addSubview(numberLabel)
        
        wordTextField.backgroundColor = UIColor.lightGray
        wordTextField.textAlignment = .center
        numberTextField.backgroundColor = UIColor.lightGray
        numberTextField.textAlignment = .center
        numberTextField.keyboardType = .numberPad
        
        view.addSubview(wordTextField)
        view.addSubview(numberTextField)
        
        view.addSubview(textView)
        
        button.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        button.setTitle("Print It", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = .blue
        view.addSubview(button)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        let word = wordTextField.text!
        let number = Int(numberTextField.text!)!
        let solutions = printIt(word: word, numberOfTimes: number)
        textView.text = solutions
    }
    
    
    //#-end-hidden-code
//: Enter the code inside the function to return a String that contains the given word the number of times corresponding the the argument numberOfTimes. Make sure to add the new line operator at the end of each word.
//:
    func printIt(word: String, numberOfTimes: Int) -> String
    {
        <#Code#>
    }
    //#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
