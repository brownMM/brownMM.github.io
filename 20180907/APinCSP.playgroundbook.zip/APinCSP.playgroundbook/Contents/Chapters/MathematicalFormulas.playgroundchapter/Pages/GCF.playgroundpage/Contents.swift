//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let ElementLabel0 = UILabel(frame: CGRect(x: 100, y: 40, width: 60, height: 40))
    let ElementTextField0 = UITextField(frame: CGRect(x: 160, y: 40, width: 40, height: 40))
    
    let ElementLabel3 = UILabel(frame: CGRect(x: 100, y: 100, width: 60, height: 40))
    let ElementTextField2 = UITextField(frame: CGRect(x: 160, y: 100, width: 40, height: 40))
    
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 180, width: 200, height: 40))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    var array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        ElementLabel0.text = "#1:"
        ElementLabel0.textAlignment = .center
        ElementLabel0.font = UIFont(name: "Times", size: 40)
        
        ElementLabel3.text = "#2"
        ElementLabel3.textAlignment = .center
        ElementLabel3.font = UIFont(name: "Times", size: 40)
        
        
        view.addSubview(ElementLabel0)

        view.addSubview(ElementLabel3)

        
        ElementTextField0.backgroundColor = UIColor.lightGray
        ElementTextField0.textAlignment = .center
        ElementTextField0.keyboardType = .numberPad
        
        ElementTextField2.backgroundColor = UIColor.lightGray
        ElementTextField2.textAlignment = .center
        ElementTextField2.keyboardType = .numberPad
        
        view.addSubview(ElementTextField0)

        view.addSubview(ElementTextField2)
        
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed(_:)), for: .touchUpInside)
        totalButton.setTitle("Find It", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        let A = Int(ElementTextField0.text!)!
        let B = Int(ElementTextField2.text!)!
        let solution = greatestCommonFactor(A: A, B: B)
        totalLabel.text = "GCF of \(A) and \(B) = \(solution)"
    }
    
    
//#-end-hidden-code
//: Enter the code inside the function to find the Greatest Common Factor of the two numbers.
//:

    func greatestCommonFactor(A: Int, B: Int) -> Int
    {
        <#Code#>
    }
    //#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


