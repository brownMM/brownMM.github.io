//
//  Point.swift
//  
//
//  Created by Robert D. Brown on 9/4/17.
//

import Foundation


public class Point {
    public var x: Double
    public var y: Double
    
    public init(x: Double, y: Double)
    {
        self.x = x
        self.y = y
    }
}
