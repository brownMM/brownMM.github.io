//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let ElementLabel0 = UILabel(frame: CGRect(x: 20, y: 40, width: 40, height: 40))
    let ElementLabel1 = UILabel(frame: CGRect(x: 100, y: 40, width: 40, height: 40))
    let ElementLabel2 = UILabel(frame: CGRect(x: 180, y: 40, width: 40, height: 40))
    let ElementLabel3 = UILabel(frame: CGRect(x: 260, y: 40, width: 40, height: 40))
    let ElementLabel4 = UILabel(frame: CGRect(x: 340, y: 40, width: 40, height: 40))
    
    let ElementTextField0 = UITextField(frame: CGRect(x: 20, y: 80, width: 40, height: 40))
    let ElementTextField1 = UITextField(frame: CGRect(x: 100, y: 80, width: 40, height: 40))
    let ElementTextField2 = UITextField(frame: CGRect(x: 180, y: 80, width: 40, height: 40))
    let ElementTextField3 = UITextField(frame: CGRect(x: 260, y: 80, width: 40, height: 40))
    let ElementTextField4 = UITextField(frame: CGRect(x: 340, y: 80, width: 40, height: 40))
    
    let maximumLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 400, height: 100))
    
    let maximumButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    var array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        ElementLabel0.text = "0"
        ElementLabel0.textAlignment = .center
        ElementLabel1.text = "1"
        ElementLabel1.textAlignment = .center
        ElementLabel2.text = "2"
        ElementLabel2.textAlignment = .center
        ElementLabel3.text = "3"
        ElementLabel3.textAlignment = .center
        ElementLabel4.text = "4"
        ElementLabel4.textAlignment = .center
        
        view.addSubview(ElementLabel0)
        view.addSubview(ElementLabel1)
        view.addSubview(ElementLabel2)
        view.addSubview(ElementLabel3)
        view.addSubview(ElementLabel4)
        
        ElementTextField0.backgroundColor = UIColor.lightGray
        ElementTextField0.textAlignment = .center
        ElementTextField0.keyboardType = .numberPad
        ElementTextField1.backgroundColor = UIColor.lightGray
        ElementTextField1.textAlignment = .center
        ElementTextField1.keyboardType = .numberPad
        ElementTextField2.backgroundColor = UIColor.lightGray
        ElementTextField2.textAlignment = .center
        ElementTextField2.keyboardType = .numberPad
        ElementTextField3.backgroundColor = UIColor.lightGray
        ElementTextField3.textAlignment = .center
        ElementTextField3.keyboardType = .numberPad
        ElementTextField4.backgroundColor = UIColor.lightGray
        ElementTextField4.textAlignment = .center
        ElementTextField4.keyboardType = .numberPad
        
        view.addSubview(ElementTextField0)
        view.addSubview(ElementTextField1)
        view.addSubview(ElementTextField2)
        view.addSubview(ElementTextField3)
        view.addSubview(ElementTextField4)
        
        maximumLabel.numberOfLines = 2
        view.addSubview(maximumLabel)
        
        maximumButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        maximumButton.setTitle("Find Max", for: .normal)
        maximumButton.setTitleColor(UIColor.white, for: .normal)
        maximumButton.backgroundColor = .blue
        view.addSubview(maximumButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        ElementTextField4.resignFirstResponder()
        array = [Int(ElementTextField0.text!)!,Int(ElementTextField1.text!)!,Int(ElementTextField2.text!)!,Int(ElementTextField3.text!)!,Int(ElementTextField4.text!)!]
        let maxMaximum = findMaximumWithMax(array: array)
        let loopMaximum = findMaximumWithLoop(array: array)
        maximumLabel.text = "With max, maximum is \(maxMaximum).\nWith your code, maximum is \(loopMaximum)."
    }
    
    func findMaximumWithMax(array: [Int]) -> Int
    {
        return array.max()!
    }
    
    
//#-end-hidden-code
//: Enter the code inside the function to find the maximum value of the array. You must use a loop and you may not use the max method. DO NOT assume you know how many elements are in the array.
//:
//: ![Function with maximum](MaximumFunction.png)
//:
    func findMaximumWithLoop(array: [Int]) -> Int
    {
        <#Code#>
    }
//#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


