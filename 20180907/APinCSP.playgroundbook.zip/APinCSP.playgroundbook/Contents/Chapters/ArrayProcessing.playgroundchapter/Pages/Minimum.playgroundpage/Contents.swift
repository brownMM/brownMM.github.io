//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let ElementLabel0 = UILabel(frame: CGRect(x: 20, y: 40, width: 40, height: 40))
    let ElementLabel1 = UILabel(frame: CGRect(x: 90, y: 40, width: 40, height: 40))
    let ElementLabel2 = UILabel(frame: CGRect(x: 160, y: 40, width: 40, height: 40))
    let ElementLabel3 = UILabel(frame: CGRect(x: 220, y: 40, width: 40, height: 40))
    let ElementLabel4 = UILabel(frame: CGRect(x: 290, y: 40, width: 40, height: 40))
    let ElementLabel5 = UILabel(frame: CGRect(x: 360, y: 40, width: 40, height: 40))
    
    let ElementTextField0 = UITextField(frame: CGRect(x: 20, y: 80, width: 40, height: 40))
    let ElementTextField1 = UITextField(frame: CGRect(x: 90, y: 80, width: 40, height: 40))
    let ElementTextField2 = UITextField(frame: CGRect(x: 160, y: 80, width: 40, height: 40))
    let ElementTextField3 = UITextField(frame: CGRect(x: 220, y: 80, width: 40, height: 40))
    let ElementTextField4 = UITextField(frame: CGRect(x: 290, y: 80, width: 40, height: 40))
     let ElementTextField5 = UITextField(frame: CGRect(x: 360, y: 80, width: 40, height: 40))
    
    let minimumLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 400, height: 100))
    
    let minimumButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    var array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        ElementLabel0.text = "0"
        ElementLabel0.textAlignment = .center
        ElementLabel1.text = "1"
        ElementLabel1.textAlignment = .center
        ElementLabel2.text = "2"
        ElementLabel2.textAlignment = .center
        ElementLabel3.text = "3"
        ElementLabel3.textAlignment = .center
        ElementLabel4.text = "4"
        ElementLabel4.textAlignment = .center
        ElementLabel5.text = "5"
        ElementLabel5.textAlignment = .center
        
        view.addSubview(ElementLabel0)
        view.addSubview(ElementLabel1)
        view.addSubview(ElementLabel2)
        view.addSubview(ElementLabel3)
        view.addSubview(ElementLabel4)
        view.addSubview(ElementLabel5)
        
        ElementTextField0.backgroundColor = UIColor.lightGray
        ElementTextField0.textAlignment = .center
        ElementTextField0.keyboardType = .numberPad
        ElementTextField1.backgroundColor = UIColor.lightGray
        ElementTextField1.textAlignment = .center
        ElementTextField1.keyboardType = .numberPad
        ElementTextField2.backgroundColor = UIColor.lightGray
        ElementTextField2.textAlignment = .center
        ElementTextField2.keyboardType = .numberPad
        ElementTextField3.backgroundColor = UIColor.lightGray
        ElementTextField3.textAlignment = .center
        ElementTextField3.keyboardType = .numberPad
        ElementTextField4.backgroundColor = UIColor.lightGray
        ElementTextField4.textAlignment = .center
        ElementTextField4.keyboardType = .numberPad
        ElementTextField5.backgroundColor = UIColor.lightGray
        ElementTextField5.textAlignment = .center
        ElementTextField5.keyboardType = .numberPad
        
        view.addSubview(ElementTextField0)
        view.addSubview(ElementTextField1)
        view.addSubview(ElementTextField2)
        view.addSubview(ElementTextField3)
        view.addSubview(ElementTextField4)
        view.addSubview(ElementTextField5)
        
        minimumLabel.numberOfLines = 2
        view.addSubview(minimumLabel)
        
        minimumButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        minimumButton.setTitle("Find Minimum", for: .normal)
        minimumButton.setTitleColor(UIColor.white, for: .normal)
        minimumButton.backgroundColor = .blue
        view.addSubview(minimumButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        ElementTextField5.resignFirstResponder()
        array = [Int(ElementTextField0.text!)!,Int(ElementTextField1.text!)!,Int(ElementTextField2.text!)!,Int(ElementTextField3.text!)!,Int(ElementTextField4.text!)!,Int(ElementTextField5.text!)!]
        let minMinimum = findMinimumWithMin(array: array)
        let loopMinimum = findMinimumWithLoop(array: array)
        minimumLabel.text = "With min, minimum is \(minMinimum).\nWith your code, minimum is \(loopMinimum)."
    }
    
    func findMinimumWithMin(array: [Int]) -> Int
    {
        return array.min()!
    }
    
//#-end-hidden-code
//: Enter the code inside the function to find the minimum value of the array. You must use a loop and you may not use the min method. DO NOT assume you know how many elements are in the array.
//:
//: ![Function with minimum](MinimumFunction.png)
//:
    func findMinimumWithLoop(array: [Int]) -> Int
    {
        <#code#>
    }
//#-hidden-code
}


PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
