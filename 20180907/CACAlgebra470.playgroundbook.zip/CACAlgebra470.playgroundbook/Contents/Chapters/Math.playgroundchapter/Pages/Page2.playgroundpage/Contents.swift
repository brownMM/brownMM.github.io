//#-hidden-code

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController, UITextFieldDelegate {
    let functionLabel = UILabel(frame: CGRect(x: 55, y: 150, width: 320, height: 55))
    let atextField = UITextField(frame: CGRect(x: 105, y: 160, width: 51, height: 40))
    let btextField = UITextField(frame: CGRect(x: 192, y: 160, width: 51, height: 40))
    let answerLabel = UILabel(frame: CGRect(x: 318, y: 160, width: 50, height: 40))
    let aTextView = UITextView(frame:CGRect(x: 70, y: 360, width: 95, height: 250))
    let bTextView = UITextView(frame:CGRect(x: 170, y: 360, width: 95, height: 250))
    let yTextView = UITextView(frame:CGRect(x: 270, y: 360, width: 95, height: 250))
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        atextField.delegate = self
        btextField.delegate = self
        
        let label = UILabel()
        label.frame = CGRect(x: 10, y: 10, width: 150, height: 70)
        label.font = UIFont(name: "Times-Italic", size: 40.0)
        label.text = "f(a,b)="
        label.textColor = .black
        label.textAlignment = .center
        view.addSubview(label)
        
        let borderView = UIView(frame: CGRect(x: 160, y: 10, width: 264, height: 74))
        borderView.backgroundColor = .black
        let drawingView = DrawView(frame: CGRect(x: 2, y: 2, width: 260, height: 70))
        drawingView.backgroundColor = .white
        borderView.addSubview(drawingView)
        view.addSubview(borderView)
        
        let calculateButton = UIButton(frame: CGRect(x: 10, y: 100, width: 200, height: 40))
        calculateButton.setTitle("Calculate", for: .normal)
        calculateButton.backgroundColor = .orange
        calculateButton.addTarget(self, action: #selector(getValue), for: .touchUpInside)
        view.addSubview(calculateButton)
        
        let addToTableButton = UIButton(frame: CGRect(x: 220, y: 100, width: 200, height: 40))
        addToTableButton.setTitle("Add to Table", for: .normal)
        addToTableButton.addTarget(self, action: #selector(addToTable), for: .touchUpInside)
        addToTableButton.backgroundColor = .orange
        view.addSubview(addToTableButton)
        
        
        functionLabel.font = UIFont(name: "Times-Italic", size: 50.0)
        functionLabel.text = "f( __ , __ )= __"
        functionLabel.textAlignment = .center
        view.addSubview(functionLabel)
        
        atextField.font = UIFont(name: "Times", size: 50.0)
        atextField.textAlignment = .center
        //        atextField.backgroundColor = .lightGray
        atextField.keyboardType = .numberPad
        view.addSubview(atextField)
        
        btextField.font = UIFont(name: "Times", size: 50.0)
        btextField.textAlignment = .center
        //        btextField.backgroundColor = .lightGray
        btextField.keyboardType = .numberPad
        view.addSubview(btextField)
        
        answerLabel.font = UIFont(name: "Times", size: 50.0)
        //        answerLabel.backgroundColor = .lightGray
        answerLabel.textAlignment = .center
        view.addSubview(answerLabel)
        
        
        let tableBackground = UIView(frame: CGRect(x: 70, y: 300, width: 295, height: 300))
        tableBackground.backgroundColor = .black
        view.addSubview(tableBackground)
        
        let aLabel = UILabel(frame: CGRect(x: 70, y: 300, width: 95, height: 50))
        aLabel.text = "a"
        aLabel.font = UIFont(name: "Times-Italic", size: 40.0)
        aLabel.backgroundColor = .white
        aLabel.textColor = .black
        aLabel.textAlignment = .center
        view.addSubview(aLabel)
        
        let bLabel = UILabel(frame: CGRect(x: 170, y: 300, width: 95, height: 50))
        bLabel.text = "b"
        bLabel.font = UIFont(name: "Times-Italic", size: 40.0)
        bLabel.backgroundColor = .white
        bLabel.textColor = .black
        bLabel.textAlignment = .center
        view.addSubview(bLabel)
        
        let yLabel = UILabel(frame: CGRect(x: 270, y: 300, width: 95, height: 50))
        yLabel.text = "f(a,b)"
        yLabel.font = UIFont(name: "Times-Italic", size: 40.0)
        yLabel.backgroundColor = .white
        yLabel.textColor = .black
        yLabel.textAlignment = .center
        view.addSubview(yLabel)
        
        
        aTextView.font = UIFont(name: "Times-Italic", size: 40.0)
        aTextView.backgroundColor = .white
        aTextView.textColor = .black
        aTextView.textAlignment = .center
        view.addSubview(aTextView)
        
        bTextView.font = UIFont(name: "Times-Italic", size: 40.0)
        bTextView.backgroundColor = .white
        bTextView.textColor = .black
        bTextView.textAlignment = .center
        view.addSubview(bTextView)
        
        yTextView.font = UIFont(name: "Times-Italic", size: 40.0)
        yTextView.backgroundColor = .white
        yTextView.textColor = .black
        yTextView.textAlignment = .center
        view.addSubview(yTextView)
        
        self.view = view
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        getValue()
        return true
    }
    
    @objc func getValue()
    {
        atextField.resignFirstResponder()
        btextField.resignFirstResponder()
        if let aValue = atextField.text,let bValue = btextField.text
        {
            if let a = Int(aValue), let b = Int(bValue)
            {
                answerLabel.text = "\(f(a:a,b:b))"
            }
        }
    }
    //#-end-hidden-code
//: As an example below, any two inputs for a and b to the function **f** will return the sum of a and b. On the right, you can write the function f's equation inside the box. Then tap inside the function, enter a number for a, number for b and press calculate. When done, press add to Table to list the function value in the table.
//:
    func f(a:Int,b:Int) -> Int
    {
        return a + b
    }
    //#-hidden-code
    
    @objc func addToTable()
    {
        if let aValue = atextField.text {
            aTextView.text = aTextView.text + "\(aValue)\n"
        }
        
        if let bValue = btextField.text {
            bTextView.text = bTextView.text + "\(bValue)\n"
        }
        
        if let yValue = answerLabel.text {
            yTextView.text = yTextView.text + "\(yValue)\n"
        }
        
        atextField.text = ""
        btextField.text = ""
        answerLabel.text = ""
    }
}

PlaygroundPage.current.liveView = MyViewController()
//#-end-hidden-code

