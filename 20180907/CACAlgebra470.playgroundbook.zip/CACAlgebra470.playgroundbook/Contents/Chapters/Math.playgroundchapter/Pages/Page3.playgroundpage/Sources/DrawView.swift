import UIKit

public class DrawView: UIView {
    
    var lines: [Line] = []
    var lastPoint: CGPoint!
    var drawColor = UIColor.black
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.lastPoint = touches.first?.location(in: self)
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let newPoint = touches.first?.location(in: self)
        self.lines.append(Line(start: self.lastPoint, end: newPoint!, color: self.drawColor))
        self.lastPoint = newPoint
        
        self.setNeedsDisplay()
    }
    
    public override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()!
        context.setLineCap(.round)
        context.setLineWidth(3)
        
        for line in self.lines {
            context.beginPath()
            context.move(to: CGPoint(x: line.startX, y: line.startY))
            context.addLine(to: CGPoint(x: line.endX, y: line.endY))
            context.setStrokeColor(line.color.cgColor)
            context.strokePath()
        }
    }
    
}

