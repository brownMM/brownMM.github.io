//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let ElementLabel0 = UILabel(frame: CGRect(x: 100, y: 40, width: 60, height: 40))
    let ElementTextField0 = UITextField(frame: CGRect(x: 160, y: 40, width: 40, height: 40))
    let ElementLabel1 = UILabel(frame: CGRect(x: 200, y: 40, width: 20, height: 40))
    let ElementTextField1 = UITextField(frame: CGRect(x: 220, y: 40, width: 40, height: 40))
    let ElementLabel2 = UILabel(frame: CGRect(x: 260, y: 40, width: 20, height: 40))
    
    
    let ElementLabel3 = UILabel(frame: CGRect(x: 100, y: 100, width: 60, height: 40))
    let ElementTextField2 = UITextField(frame: CGRect(x: 160, y: 100, width: 40, height: 40))
    let ElementLabel4 = UILabel(frame: CGRect(x: 200, y: 100, width: 20, height: 40))
    let ElementTextField3 = UITextField(frame: CGRect(x: 220, y: 100, width: 40, height: 40))
    let ElementLabel5 = UILabel(frame: CGRect(x: 260, y: 100, width: 20, height: 40))
    
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 180, width: 200, height: 40))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    var array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        ElementLabel0.text = "A:("
        ElementLabel0.textAlignment = .center
        ElementLabel0.font = UIFont(name: "Times", size: 40)
        ElementLabel1.text = ","
        ElementLabel1.textAlignment = .center
        ElementLabel1.font = UIFont(name: "Times", size: 40)
        ElementLabel2.text = ")"
        ElementLabel2.textAlignment = .center
        ElementLabel2.font = UIFont(name: "Times", size: 40)
        ElementLabel3.text = "B:("
        ElementLabel3.textAlignment = .center
        ElementLabel3.font = UIFont(name: "Times", size: 40)
        ElementLabel4.text = ","
        ElementLabel4.textAlignment = .center
        ElementLabel4.font = UIFont(name: "Times", size: 40)
        ElementLabel5.text = ")"
        ElementLabel5.textAlignment = .center
        ElementLabel5.font = UIFont(name: "Times", size: 40)
        
        view.addSubview(ElementLabel0)
        view.addSubview(ElementLabel1)
        view.addSubview(ElementLabel2)
        view.addSubview(ElementLabel3)
        view.addSubview(ElementLabel4)
        view.addSubview(ElementLabel5)
        
        ElementTextField0.backgroundColor = UIColor.lightGray
        ElementTextField0.textAlignment = .center
        ElementTextField0.keyboardType = .numberPad
        ElementTextField1.backgroundColor = UIColor.lightGray
        ElementTextField1.textAlignment = .center
        ElementTextField1.keyboardType = .numberPad
        ElementTextField2.backgroundColor = UIColor.lightGray
        ElementTextField2.textAlignment = .center
        ElementTextField2.keyboardType = .numberPad
        ElementTextField3.backgroundColor = UIColor.lightGray
        ElementTextField3.textAlignment = .center
        ElementTextField3.keyboardType = .numberPad
        
        view.addSubview(ElementTextField0)
        view.addSubview(ElementTextField1)
        view.addSubview(ElementTextField2)
        view.addSubview(ElementTextField3)
        
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed(_:)), for: .touchUpInside)
        totalButton.setTitle("Find It", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        let A = Point(x: Double(ElementTextField0.text!)!, y: Double(ElementTextField1.text!)!)
        let B = Point(x: Double(ElementTextField2.text!)!, y: Double(ElementTextField3.text!)!)
        let solution = distanceFormula(A: A, B: B)
        totalLabel.text = "Distance = \(solution)"
    }
    
    
//#-end-hidden-code
//: Enter the code inside the function to produce the distance between any two points. The function will receive two Point objects, A and B. It should return the solution as a Double.
//:
//: ![Distance Formula](DistanceFormula.png)
    func distanceFormula(A: Point, B: Point) -> Double
    {
        <#Code#>
    }
    //#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code


