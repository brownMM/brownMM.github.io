//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let ElementLabel0 = UILabel(frame: CGRect(x: 20, y: 40, width: 40, height: 40))
    let ElementLabel1 = UILabel(frame: CGRect(x: 100, y: 40, width: 40, height: 40))
    let ElementLabel2 = UILabel(frame: CGRect(x: 180, y: 40, width: 40, height: 40))
    
    let ElementTextField0 = UITextField(frame: CGRect(x: 20, y: 80, width: 40, height: 40))
    let ElementTextField1 = UITextField(frame: CGRect(x: 100, y: 80, width: 40, height: 40))
    let ElementTextField2 = UITextField(frame: CGRect(x: 180, y: 80, width: 40, height: 40))
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 200, height: 40))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 150, height: 25))
    
    var array = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        ElementLabel0.text = "A:"
        ElementLabel0.textAlignment = .center
        ElementLabel1.text = "B:"
        ElementLabel1.textAlignment = .center
        ElementLabel2.text = "C:"
        ElementLabel2.textAlignment = .center
        
        view.addSubview(ElementLabel0)
        view.addSubview(ElementLabel1)
        view.addSubview(ElementLabel2)
        
        ElementTextField0.backgroundColor = UIColor.lightGray
        ElementTextField0.textAlignment = .center
        ElementTextField0.keyboardType = .numberPad
        ElementTextField1.backgroundColor = UIColor.lightGray
        ElementTextField1.textAlignment = .center
        ElementTextField1.keyboardType = .numberPad
        ElementTextField2.backgroundColor = UIColor.lightGray
        ElementTextField2.textAlignment = .center
        ElementTextField2.keyboardType = .numberPad
        
        view.addSubview(ElementTextField0)
        view.addSubview(ElementTextField1)
        view.addSubview(ElementTextField2)
        
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Find It", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        let a = Double(ElementTextField0.text!)!
        let b = Double(ElementTextField1.text!)!
        let c = Double(ElementTextField2.text!)!
        let solutions = quadraticFormula(a: a, b: b, c: c)
        totalLabel.text = "x = \(solutions.0) and x = \(solutions.1)"
    }
    
    
//#-end-hidden-code
//: Enter the code inside the function to produce the two solutions to any quadratic equation given. The function will receive the A, B and C values as Double arguments. It should return the solutions as a Double tuple.
//:
//: ![Quadratic Formula](QuadraticFormula.png)
    func quadraticFormula(a: Double, b: Double, c: Double) -> (Double,Double)
    {
        <#code#>
    }
//#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
