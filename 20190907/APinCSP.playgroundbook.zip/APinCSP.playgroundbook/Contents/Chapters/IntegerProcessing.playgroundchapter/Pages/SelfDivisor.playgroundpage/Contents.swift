//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let integerLabel = UILabel(frame: CGRect(x: 20, y: 40, width: 350, height: 40))
    
    let integerTextField = UITextField(frame: CGRect(x: 20, y: 80, width: 100, height: 40))
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 300, height: 40))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 250, height: 25))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        integerLabel.text = "Enter an Integer Below"
        view.addSubview(integerLabel)
        
        integerTextField.backgroundColor = UIColor.lightGray
        view.addSubview(integerTextField)
        
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Check", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        let integer = Int(integerTextField.text!)!
        totalLabel.text = "Is \(integer) a self divisor? \(isSelfDivisor(number: integer))"
    }
    
    
//#-end-hidden-code
//: A positive integer is called a "self-divisor" if every decimal digit of the number is a divisor of the number, that is, the number is evenly divisible by each and every one of its digits. For example, the number 128 is a self-divisor because it is evenly divisible by 1,2, and 8. However, 26 is not a self-divisor because it is not evenly divisible by the digit 6.
//: Note that 0 is not considered to be a divisor of any number, so any number containing a 0 digit is NOT a self-divisor. There are infinitely many self-divisors.
//:
//: Write method isSelfDivisor, which takes a positive integer as its parameter.
//:This method returns true if the number is a self-divisor; otherwise, it returns false.
//:
    func isSelfDivisor(number: Int) -> Bool
    {
        <#code#>
    }
    //#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

