//#-hidden-code
import UIKit
import PlaygroundSupport

class ViewController: UIViewController
{
    let integerLabel = UILabel(frame: CGRect(x: 20, y: 40, width: 350, height: 40))
    
    let integerTextField = UITextField(frame: CGRect(x: 20, y: 80, width: 100, height: 40))
    
    let totalLabel = UILabel(frame: CGRect(x: 20, y: 150, width: 400, height: 80))
    
    let totalButton = UIButton(frame: CGRect(x: 125, y: 10 , width: 250, height: 25))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        integerLabel.text = "Enter a Digit to find"
        view.addSubview(integerLabel)
        
        integerTextField.backgroundColor = UIColor.lightGray
        view.addSubview(integerTextField)
        
        totalLabel.numberOfLines = 2
        view.addSubview(totalLabel)
        
        totalButton.addTarget(self, action: #selector(whenPressed), for: .touchUpInside)
        totalButton.setTitle("Find the Digit", for: .normal)
        totalButton.setTitleColor(UIColor.white, for: .normal)
        totalButton.backgroundColor = .blue
        view.addSubview(totalButton)
    }
    
    @objc func whenPressed(_ button: UIButton)
    {
        let digit = Int(integerTextField.text!)!
        let randomNumber = arc4random_uniform(10000) + 1
        let answer = findIt(number: Int(randomNumber), digit: digit)
        if answer == "not found" {
            totalLabel.text = "In \(randomNumber), the digit \(digit) was \(answer)"
        } else {
            totalLabel.text = "In \(randomNumber), the digit \(digit) is in the \(answer) position"
        }
        
    }
    
    
    //#-end-hidden-code
//: Enter the code inside the function to take the argument number and the argument digit and find the last position of the digit. Example, if given the number 1234 and the digit 2, the function will return hundreds. If the digit is not in the integer, then return the string "not found". The number will be randomly generated, you will only need to enter the digit to find.
    
    func findIt(number: Int,digit: Int) -> String
    {
        <#code#>
    }
    //#-hidden-code
}





PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
