//#-hidden-code

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController, UITextFieldDelegate {
    let functionLabel = UILabel(frame: CGRect(x: 75, y: 150, width: 300, height: 55))
    let textField = UITextField(frame: CGRect(x: 128, y: 160, width: 51, height: 40))
    let answerLabel = UILabel(frame: CGRect(x: 254, y: 160, width: 100, height: 40))
    let xTextView = UITextView(frame:CGRect(x: 130, y: 360, width: 95, height: 250))
    let yTextView = UITextView(frame:CGRect(x: 235, y: 360, width: 95, height: 250))
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        textField.delegate = self
        
        let label = UILabel()
        label.frame = CGRect(x: 10, y: 10, width: 150, height: 70)
        label.font = UIFont(name: "Times-Italic", size: 60.0)
        label.text = "f(x)="
        label.textColor = .black
        label.textAlignment = .center
        view.addSubview(label)
        
        let borderView = UIView(frame: CGRect(x: 160, y: 10, width: 264, height: 74))
        borderView.backgroundColor = .black
        let drawingView = DrawView(frame: CGRect(x: 2, y: 2, width: 260, height: 70))
        drawingView.backgroundColor = .white
        borderView.addSubview(drawingView)
        view.addSubview(borderView)
        
        let calculateButton = UIButton(frame: CGRect(x: 10, y: 100, width: 200, height: 40))
        calculateButton.setTitle("Calculate", for: .normal)
        calculateButton.backgroundColor = .orange
        calculateButton.addTarget(self, action: #selector(getValue), for: .touchUpInside)
        view.addSubview(calculateButton)
        
        let addToTableButton = UIButton(frame: CGRect(x: 220, y: 100, width: 200, height: 40))
        addToTableButton.setTitle("Add to Table", for: .normal)
        addToTableButton.addTarget(self, action: #selector(addToTable), for: .touchUpInside)
        addToTableButton.backgroundColor = .orange
        view.addSubview(addToTableButton)
        
        
        functionLabel.font = UIFont(name: "Times-Italic", size: 50.0)
        functionLabel.text = "f( __ )= ___"
        functionLabel.textAlignment = .center
        view.addSubview(functionLabel)
        
        textField.font = UIFont(name: "Times", size: 50.0)
        textField.textAlignment = .center
        //        textField.backgroundColor = .lightGray
        textField.keyboardType = .numberPad
        view.addSubview(textField)
        
        answerLabel.font = UIFont(name: "Times", size: 50.0)
        //        answerLabel.backgroundColor = .lightGray
        answerLabel.textAlignment = .center
        view.addSubview(answerLabel)
        
        
        let tableBackground = UIView(frame: CGRect(x: 130, y: 300, width: 200, height: 300))
        tableBackground.backgroundColor = .black
        view.addSubview(tableBackground)
        
        let xLabel = UILabel(frame: CGRect(x: 130, y: 300, width: 95, height: 50))
        xLabel.text = "x"
        xLabel.font = UIFont(name: "Times-Italic", size: 40.0)
        xLabel.backgroundColor = .white
        xLabel.textColor = .black
        xLabel.textAlignment = .center
        view.addSubview(xLabel)
        
        let yLabel = UILabel(frame: CGRect(x: 235, y: 300, width: 95, height: 50))
        yLabel.text = "f(x)"
        yLabel.font = UIFont(name: "Times-Italic", size: 40.0)
        yLabel.backgroundColor = .white
        yLabel.textColor = .black
        yLabel.textAlignment = .center
        view.addSubview(yLabel)
        
        
        xTextView.font = UIFont(name: "Times-Italic", size: 40.0)
        xTextView.backgroundColor = .white
        xTextView.textColor = .black
        xTextView.textAlignment = .center
        view.addSubview(xTextView)
        
        yTextView.font = UIFont(name: "Times-Italic", size: 40.0)
        yTextView.backgroundColor = .white
        yTextView.textColor = .black
        yTextView.textAlignment = .center
        view.addSubview(yTextView)
        
        self.view = view
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        getValue()
        return true
    }
    
    @objc func getValue()
    {
        textField.resignFirstResponder()
        if let value = textField.text
        {
            if let x = Double(value)
            {
                answerLabel.text = "\(f(x: x))"
            }
        }
    }
//#-end-hidden-code
//: ![FunctionMachine](FunctionMachine.png)
//: As an example below, any input the the function **f** will return the value of 5. On the right, you can write the function f's equation inside the box. Then tap inside the function, enter a number and press calculate. When done, press add to Table to list the function value in the table.
//:
    func f(x:Double) -> Double
    {
        return 5
    }
    //#-hidden-code
    
    @objc func addToTable()
    {
        if let xValue = textField.text {
            xTextView.text = xTextView.text + "\(xValue)\n"
        }
        
        if let yValue = answerLabel.text {
            yTextView.text = yTextView.text + "\(yValue)\n"
        }
        
        textField.text = ""
        answerLabel.text = ""
    }
}

PlaygroundPage.current.liveView = MyViewController()
//#-end-hidden-code

